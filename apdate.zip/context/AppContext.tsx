
import React, { createContext, useContext, useState, useMemo, useCallback, ReactNode, useEffect } from 'react';
import { getInitialData } from '../services/initialData';
import { 
    AppData, Transaction, Business, Category, TransactionType, Client, Vendor, Item, Quotation, QuotationItem, Payment, ExpenseType 
} from '../types';
import { useAuth } from './AuthContext';
import { db, serverTimestamp } from '../firebase';
import firebase from 'firebase/compat/app';


interface ConfirmationState {
    isOpen: boolean;
    title: string;
    message: React.ReactNode;
    onConfirm: () => void;
}

interface AppContextType {
    appData: AppData;
    setAppData: React.Dispatch<React.SetStateAction<AppData>>;
    isDataLoading: boolean;
    activeBusinessId: string | null;
    setActiveBusinessId: (id: string | null) => void;
    activeBusiness: Business | null;
    dataForActiveBusiness: {
        visibleTransactions: Transaction[];
        quotations: Quotation[];
        clients: Client[];
        vendors: Vendor[];
        items: Item[];
    };
    usedClientIds: Set<string>;
    usedVendorIds: Set<string>;
    addTransaction: (transaction: Omit<Transaction, 'id' | 'businessId' | 'transactionNumber' | 'status' | 'payments' | 'ownerId'>, isBill?: boolean) => Promise<void>;
    updateTransaction: (transaction: Transaction) => Promise<void>;
    deleteTransaction: (id: string) => void;
    addPayment: (transactionId: string, payment: Omit<Payment, 'id'>) => Promise<void>;
    addQuotation: (quotationData: Omit<Quotation, 'id' | 'businessId' | 'quotationNumber' | 'ownerId'>) => Promise<void>;
    updateQuotation: (quotation: Quotation) => Promise<void>;
    deleteQuotation: (id: string) => void;
    convertQuoteToInvoice: (quote: Quotation) => Promise<void>;
    createInvoiceFromScratch: (quoteData: Omit<Quotation, 'id' | 'businessId' | 'quotationNumber' | 'ownerId'>) => Promise<void>;
    addCategory: (name: string, type: TransactionType, expenseType?: ExpenseType) => Promise<void>;
    addItem: (itemData: Omit<Item, 'id' | 'ownerId'>) => Promise<Item>;
    addClient: (clientData: Omit<Client, 'id' | 'ownerId'>) => Promise<Client>;
    updateClient: (client: Client) => Promise<void>;
    deleteClient: (id: string, isUsed: boolean) => void;
    addVendor: (vendorData: Omit<Vendor, 'id' | 'ownerId'>) => Promise<Vendor>;
    updateVendor: (vendor: Vendor) => Promise<void>;
    deleteVendor: (id: string, isUsed: boolean) => void;
    addBusiness: (businessData: Omit<Business, 'id' | 'ownerId'>) => Promise<void>;
    updateBusiness: (business: Business) => Promise<void>;
    onOnboardingComplete: (businessName: string, currency: string, openingBalance: number) => Promise<void>;
    confirmationState: ConfirmationState;
    askForConfirmation: (title: string, message: React.ReactNode, onConfirm: () => void) => void;
    closeConfirmation: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const emptyInitialData: AppData = {
    businesses: [],
    transactions: [],
    settings: { theme: 'dark', isPinEnabled: false, pin: null },
    categories: [],
    clients: [],
    vendors: [],
    items: [],
    quotations: [],
}

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [appData, setAppData] = useState<AppData>(emptyInitialData);
    const [isDataLoading, setIsDataLoading] = useState(true);
    const [activeBusinessId, setActiveBusinessId] = useState<string | null>(null);

    // Fetch all user data from Firestore when user logs in
    useEffect(() => {
        const fetchUserData = async () => {
            if (!user) {
                setAppData(emptyInitialData);
                setActiveBusinessId(null);
                setIsDataLoading(false);
                return;
            };

            setIsDataLoading(true);
            try {
                // Fetch user-specific settings and active business ID first
                const userDocRef = db.collection('users').doc(user.uid);
                const userDocSnap = await userDocRef.get();
                const userData = userDocSnap.data();

                const settings = userData?.settings || getInitialData().settings;
                const lastActiveBusinessId = userData?.activeBusinessId || null;

                // Fetch all collections owned by the user
                const collectionsToFetch = ['businesses', 'transactions', 'categories', 'clients', 'vendors', 'items', 'quotations'];
                const queries = collectionsToFetch.map(col => 
                    db.collection(col).where('ownerId', '==', user.uid).get()
                );

                const querySnapshots = await Promise.all(queries);
                
                const fetchedData: Partial<AppData> = {};
                querySnapshots.forEach((snapshot, index) => {
                    const collectionName = collectionsToFetch[index] as keyof AppData;
                    fetchedData[collectionName] = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as any;
                });

                const loadedAppData = { ...emptyInitialData, ...fetchedData, settings };
                setAppData(loadedAppData);
                
                // Determine active business
                const businesses = loadedAppData.businesses || [];
                const isValidLastActive = businesses.some(b => b.id === lastActiveBusinessId);
                if (isValidLastActive) {
                    setActiveBusinessId(lastActiveBusinessId);
                } else if (businesses.length > 0) {
                    setActiveBusinessId(businesses[0].id);
                } else {
                    setActiveBusinessId(null);
                }

            } catch (error) {
                console.error("Error fetching user data:", error);
                setAppData(emptyInitialData);
            } finally {
                setIsDataLoading(false);
            }
        };

        fetchUserData();
    }, [user]);

    // Persist active business ID and user settings
    const updateUserSettings = async (settings: any, businessId?: string | null) => {
        if (!user) return;
        const userDocRef = db.collection('users').doc(user.uid);
        const payload: any = { settings };
        if (businessId !== undefined) {
             payload.activeBusinessId = businessId;
        }
        await userDocRef.set(payload, { merge: true });
    };

    const handleSetActiveBusinessId = (id: string | null) => {
        setActiveBusinessId(id);
        updateUserSettings(appData.settings, id);
    };

    const handleSetAppData = (updater: React.SetStateAction<AppData>) => {
        setAppData(prevData => {
            const newData = typeof updater === 'function' ? updater(prevData) : updater;
            // Check if settings have changed
            if (JSON.stringify(prevData.settings) !== JSON.stringify(newData.settings)) {
                updateUserSettings(newData.settings);
            }
            return newData;
        });
    };

    const [confirmationState, setConfirmationState] = useState<ConfirmationState>({
        isOpen: false,
        title: '',
        message: '',
        onConfirm: () => {},
    });

    const askForConfirmation = (title: string, message: React.ReactNode, onConfirm: () => void) => {
        setConfirmationState({ isOpen: true, title, message, onConfirm });
    };

    const closeConfirmation = useCallback(() => {
        setConfirmationState(prev => ({ ...prev, isOpen: false }));
    }, []);

    // Firestore CRUD operations
    const addBusiness = async (businessData: Omit<Business, 'id' | 'ownerId'>) => {
        if (!user) return;
        const newBusinessDoc = await db.collection('businesses').add({
            ...businessData,
            ownerId: user.uid,
            createdAt: serverTimestamp()
        });
        const newBusiness: Business = { ...businessData, id: newBusinessDoc.id, ownerId: user.uid };
        setAppData(prev => ({ ...prev, businesses: [...prev.businesses, newBusiness]}));
        if (!activeBusinessId) {
            handleSetActiveBusinessId(newBusiness.id);
        }
    };
    
    const updateBusiness = async (updatedBusiness: Business) => {
        if (!user || updatedBusiness.ownerId !== user.uid) return;
        const { id, ...dataToUpdate } = updatedBusiness;
        await db.collection('businesses').doc(id).update(dataToUpdate);
        setAppData(prev => ({ ...prev, businesses: prev.businesses.map(b => b.id === id ? updatedBusiness : b)}));
    };

    const onOnboardingComplete = async (businessName: string, currency: string, openingBalance: number) => {
        if (!user) return;
        
        const batch = db.batch();

        // Create the business
        const newBusinessRef = db.collection('businesses').doc();
        const newBusiness: Omit<Business, 'id'> = {
            name: businessName,
            currency,
            taxRate: 0,
            paymentTerms: 30,
            invoiceNotes: 'Thank you for your business!',
            ownerId: user.uid
        };
        batch.set(newBusinessRef, newBusiness);

        // Create the opening balance transaction if needed
        if (openingBalance > 0) {
            const transactionRef = db.collection('transactions').doc();
            const newTransaction: Omit<Transaction, 'id'> = {
                businessId: newBusinessRef.id,
                ownerId: user.uid,
                type: 'income',
                name: "Owner's Equity",
                description: "Initial opening balance.",
                amount: openingBalance,
                date: new Date().toISOString(),
                category: "Owner's Equity",
                transactionNumber: 'EQUITY-001',
                nature: 'service',
                status: 'paid',
                payments: [],
            };
            batch.set(transactionRef, newTransaction);
        }
        
        // Create default categories for the user
        const initialCategories = getInitialData().categories;
        initialCategories.forEach(category => {
            const categoryRef = db.collection('categories').doc();
            batch.set(categoryRef, { ...category, ownerId: user.uid, id: categoryRef.id });
        });

        await batch.commit();

        // Refetch all data to update the state correctly
        const fetchUserData = async () => {
             setIsDataLoading(true);
            try {
                const collectionsToFetch = ['businesses', 'transactions', 'categories'];
                const queries = collectionsToFetch.map(col => 
                    db.collection(col).where('ownerId', '==', user.uid).get()
                );
                const querySnapshots = await Promise.all(queries);
                
                setAppData(prev => {
                    const newData = {...prev};
                    querySnapshots.forEach((snapshot, index) => {
                         const collectionName = collectionsToFetch[index] as keyof AppData;
                         newData[collectionName] = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as any;
                    });
                    return newData;
                });
                
                handleSetActiveBusinessId(newBusinessRef.id);
                
            } catch(error) {
                console.error("Error reloading data after onboarding:", error);
            } finally {
                setIsDataLoading(false);
            }
        };

        fetchUserData();
    };

    const addTransaction = async (transactionData: Omit<Transaction, 'id' | 'businessId' | 'transactionNumber' | 'status' | 'payments' | 'ownerId'>, isBill: boolean = false) => {
        if (!activeBusinessId || !user) return;

        const incomeCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'income' && t.transactionNumber.startsWith('INV-')).length;
        const expenseCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'expense').length;

        const transactionNumber = transactionData.type === 'income' 
            ? `INV-${String(incomeCount + 1).padStart(3, '0')}`
            : `EXP-${String(expenseCount + 1).padStart(3, '0')}`;

        let status: Transaction['status'] = isBill ? 'unpaid' : 'paid';
        let payments: Payment[] = isBill ? [] : [{ id: `p-${Date.now()}`, date: transactionData.date, amount: transactionData.amount, method: 'cash' }];

        if (transactionData.orderStatus) {
            status = 'unpaid';
            payments = [];
        }

        const docRef = await db.collection('transactions').add({
            ...transactionData,
            businessId: activeBusinessId,
            ownerId: user.uid,
            transactionNumber,
            status,
            payments,
            createdAt: serverTimestamp()
        });

        const newTransaction: Transaction = {
            id: docRef.id,
            businessId: activeBusinessId,
            ownerId: user.uid,
            transactionNumber,
            status,
            payments,
            ...transactionData
        }

        setAppData(prev => ({ ...prev, transactions: [...prev.transactions, newTransaction] }));
    };

    const updateTransaction = async (updatedTransaction: Transaction) => {
        if (!user || updatedTransaction.ownerId !== user.uid) return;
        const { id, ...dataToUpdate } = updatedTransaction;
        await db.collection('transactions').doc(id).update(dataToUpdate);
        setAppData(prev => ({
            ...prev,
            transactions: prev.transactions.map(t => t.id === id ? updatedTransaction : t)
        }));
    };
    
    const deleteTransaction = (id: string) => {
        askForConfirmation('Void Transaction?', 'This will mark the transaction as voided. This action cannot be undone.', async () => {
            await db.collection('transactions').doc(id).update({ status: 'voided' });
            setAppData(prev => ({
                ...prev,
                transactions: prev.transactions.map(t => t.id === id ? { ...t, status: 'voided' } : t)
            }));
        });
    };

    const addPayment = async (transactionId: string, payment: Omit<Payment, 'id'>) => {
        const transactionRef = db.collection('transactions').doc(transactionId);
        const transactionDoc = await transactionRef.get();
        if (!transactionDoc.exists) return;
        
        const t = transactionDoc.data() as Transaction;
        const newPayments = [...t.payments, { ...payment, id: `p-${Date.now()}` }];
        const totalPaid = newPayments.reduce((sum, p) => sum + p.amount, 0);
        let newStatus: Transaction['status'] = 'partially_paid';
        if (totalPaid >= t.amount) {
            newStatus = 'paid';
        }
        await transactionRef.update({ payments: newPayments, status: newStatus });
        
        setAppData(prev => ({
            ...prev,
            transactions: prev.transactions.map(tx => tx.id === transactionId ? {...tx, payments: newPayments, status: newStatus} : tx)
        }));
    };

    // Generic add function for simple collections
    const addDocToCollection = async <T extends { id?: string; ownerId?: string }>(collectionName: string, data: Omit<T, 'id' | 'ownerId'>): Promise<T> => {
        if (!user) throw new Error("User not authenticated");
        const docRef = await db.collection(collectionName).add({
            ...data,
            ownerId: user.uid,
            createdAt: serverTimestamp()
        });
        const newDoc = { ...data, id: docRef.id, ownerId: user.uid } as T;
        setAppData(prev => ({
            ...prev,
            [collectionName]: [...(prev as any)[collectionName], newDoc]
        }));
        return newDoc;
    }

    const updateDocInCollection = async <T extends { id: string; ownerId: string }>(collectionName: string, data: T) => {
        if (!user || data.ownerId !== user.uid) return;
        const { id, ...dataToUpdate } = data;
        await db.collection(collectionName).doc(id).update(dataToUpdate);
        setAppData(prev => ({
            ...prev,
            [collectionName]: (prev as any)[collectionName].map((d: T) => d.id === id ? data : d)
        }));
    }
    
    const deleteDocFromCollection = async (collectionName: string, id: string) => {
        await db.collection(collectionName).doc(id).delete();
        setAppData(prev => ({
            ...prev,
            [collectionName]: (prev as any)[collectionName].filter((d: any) => d.id !== id)
        }));
    }

    const addQuotation = async (quotationData: Omit<Quotation, 'id' | 'businessId' | 'quotationNumber' | 'ownerId'>) => {
        if (!activeBusinessId || !user) return;
        const quoteCount = appData.quotations.filter(q => q.businessId === activeBusinessId).length;
        const quotationNumber = `QT-${String(quoteCount + 1).padStart(3, '0')}`;
        const data = { ...quotationData, businessId: activeBusinessId, quotationNumber };
        await addDocToCollection('quotations', data);
    };

    const updateQuotation = async (quotation: Quotation) => updateDocInCollection('quotations', quotation);

    const deleteQuotation = (id: string) => {
        askForConfirmation('Delete Quotation?', 'Are you sure you want to permanently delete this quotation?', () => deleteDocFromCollection('quotations', id));
    };

    const addCategory = async (name: string, type: TransactionType, expenseType?: ExpenseType) => {
        await addDocToCollection('categories', { name, type, expenseType });
    };

    const addItem = (itemData: Omit<Item, 'id' | 'ownerId'>) => addDocToCollection<Item>('items', itemData);
    const addClient = (clientData: Omit<Client, 'id' | 'ownerId'>) => addDocToCollection<Client>('clients', clientData);
    const updateClient = (client: Client) => updateDocInCollection('clients', client);
    const addVendor = (vendorData: Omit<Vendor, 'id' | 'ownerId'>) => addDocToCollection<Vendor>('vendors', vendorData);
    const updateVendor = (vendor: Vendor) => updateDocInCollection('vendors', vendor);

    const deleteClient = (id: string, isUsed: boolean) => {
        const message = isUsed 
            ? "This client is linked to some transactions. Deleting them might affect your reports. Are you sure?"
            : "Are you sure you want to delete this client?";
        askForConfirmation('Delete Client?', message, () => deleteDocFromCollection('clients', id));
    };
    
    const deleteVendor = (id: string, isUsed: boolean) => {
        const message = isUsed
            ? "This vendor is linked to some transactions. Deleting them might affect your reports. Are you sure?"
            : "Are you sure you want to delete this vendor?";
        askForConfirmation('Delete Vendor?', message, () => deleteDocFromCollection('vendors', id));
    };

     const convertQuoteToInvoice = async (quote: Quotation) => {
        if (!activeBusinessId || !user) return;
        const currentBusiness = appData.businesses.find(b => b.id === activeBusinessId);
        const incomeCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'income' && t.transactionNumber.startsWith('INV-')).length;
        
        const invoiceData: Omit<Transaction, 'id'> = {
            businessId: activeBusinessId,
            ownerId: user.uid,
            type: 'income',
            name: `Invoice from ${quote.quotationNumber}`,
            description: `Based on quotation ${quote.quotationNumber}.`,
            amount: quote.total,
            date: new Date().toISOString(),
            dueDate: new Date(new Date().setDate(new Date().getDate() + (currentBusiness?.paymentTerms || 15))).toISOString(),
            category: 'Service Revenue', 
            clientId: quote.clientId,
            transactionNumber: `INV-${String(incomeCount + 1).padStart(3, '0')}`,
            nature: 'service', 
            relatedQuotationId: quote.id,
            status: 'unpaid',
            payments: [],
        };
        
        const batch = db.batch();
        const transactionRef = db.collection('transactions').doc();
        batch.set(transactionRef, invoiceData);
        
        const quoteRef = db.collection('quotations').doc(quote.id);
        batch.update(quoteRef, { status: 'accepted' });
        
        await batch.commit();

        setAppData(prev => ({
            ...prev,
            transactions: [...prev.transactions, { ...invoiceData, id: transactionRef.id }],
            quotations: prev.quotations.map(q => q.id === quote.id ? { ...q, status: 'accepted' } : q),
        }));
    };

    const createInvoiceFromScratch = async (quoteData: Omit<Quotation, 'id' | 'businessId' | 'quotationNumber' | 'ownerId'>) => {
       if (!activeBusinessId || !user) return;
        const incomeCount = appData.transactions.filter(t => t.businessId === activeBusinessId && t.type === 'income' && t.transactionNumber.startsWith('INV-')).length;
        const newInvoiceData: Omit<Transaction, 'id' | 'ownerId'> = {
            businessId: activeBusinessId,
            type: 'income',
            name: quoteData.items.map((i: QuotationItem) => i.name).join(', '),
            description: quoteData.notes || '',
            amount: quoteData.total,
            date: quoteData.date,
            dueDate: quoteData.expiryDate,
            category: 'Service Revenue',
            clientId: quoteData.clientId,
            transactionNumber: `INV-${String(incomeCount + 1).padStart(3, '0')}`,
            nature: 'service',
            status: 'unpaid',
            payments: [],
        };
        await addDocToCollection('transactions', newInvoiceData);
    };

    const activeBusiness = useMemo(() => {
        return appData.businesses.find(b => b.id === activeBusinessId) || null;
    }, [appData.businesses, activeBusinessId]);

    const dataForActiveBusiness = useMemo(() => {
        if (!activeBusinessId) {
            return { visibleTransactions: [], quotations: [], clients: [], vendors: [], items: [] };
        }
        const transactions = appData.transactions.filter(t => t.businessId === activeBusinessId && t.status !== 'voided');
        const quotations = appData.quotations.filter(q => q.businessId === activeBusinessId);
        return {
            visibleTransactions: transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
            quotations: quotations.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
            clients: appData.clients,
            vendors: appData.vendors,
            items: appData.items,
        };
    }, [activeBusinessId, appData]);

    const usedClientIds = useMemo(() => new Set(appData.transactions.map(t => t.clientId)), [appData.transactions]);
    const usedVendorIds = useMemo(() => new Set(appData.transactions.map(t => t.vendorId)), [appData.transactions]);
    
    const contextValue: AppContextType = {
        appData,
        setAppData: handleSetAppData,
        isDataLoading,
        activeBusinessId,
        setActiveBusinessId: handleSetActiveBusinessId,
        activeBusiness,
        dataForActiveBusiness,
        usedClientIds,
        usedVendorIds,
        addTransaction,
        updateTransaction,
        deleteTransaction,
        addPayment,
        addQuotation,
        updateQuotation,
        deleteQuotation,
        convertQuoteToInvoice,
        createInvoiceFromScratch,
        addCategory,
        addItem,
        addClient,
        updateClient,
        deleteClient,
        addVendor,
        updateVendor,
        deleteVendor,
        addBusiness,
        updateBusiness,
        onOnboardingComplete,
        confirmationState,
        askForConfirmation,
        closeConfirmation,
    };

    return (
        <AppContext.Provider value={contextValue}>
            {children}
        </AppContext.Provider>
    );
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};