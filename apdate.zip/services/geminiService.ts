import { Transaction, Client, Vendor, ExpenseType, expenseTypes, Category, Item, PartialTransaction, TransactionType, QuotationItem, Business } from '../types';

// NOTE: All functions in this file have been refactored to call a backend API.
// This is a critical step to make the app "Firebase ready" by securing the API key
// on a server (e.g., Firebase Cloud Functions) instead of exposing it on the client.

/**
 * Generates a financial insight by streaming the response from the backend.
 * @returns An async generator that yields chunks of the response text.
 */
export async function* generateFinancialInsightStream(
    prompt: string, 
    transactions: Transaction[],
    currency: string,
    clients: Client[],
    vendors: Vendor[]
): AsyncGenerator<{ text: string }> {
    try {
        const response = await fetch('/api/generate-insight', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt, transactions, currency, clients, vendors }),
        });

        if (!response.ok) {
            throw new Error(`API error: ${response.statusText}`);
        }
        if (!response.body) {
            throw new Error("Response body is null");
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            yield { text: decoder.decode(value, { stream: true }) };
        }
    } catch (error) {
        console.error("Error generating content from API:", error);
        yield { text: "Sorry, I'm having trouble connecting to the assistant. Please try again later." };
    }
}

/**
 * Calls the backend to recommend an expense type for a given category name.
 */
export const recommendExpenseType = async (categoryName: string): Promise<ExpenseType | null> => {
    if (!categoryName.trim()) return null;
    try {
        const response = await fetch('/api/recommend-expense-type', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ categoryName }),
        });
        if (!response.ok) throw new Error('API request failed');
        const recommendedType = await response.text();
        if (expenseTypes.includes(recommendedType.trim() as ExpenseType)) {
            return recommendedType.trim() as ExpenseType;
        }
        return null;
    } catch (error) {
        console.error("Error recommending expense type from API:", error);
        return null;
    }
};

/**
 * Calls the backend to get a simple explanation for a financial term.
 */
export const getTermExplanation = async (term: string): Promise<string> => {
    try {
        const response = await fetch('/api/get-term-explanation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ term }),
        });
        if (!response.ok) throw new Error('API request failed');
        return await response.text();
    } catch (error) {
        console.error(`Error explaining term "${term}" from API:`, error);
        return "Sorry, I couldn't fetch an explanation at this moment. Please try again.";
    }
};

/**
 * Calls the backend to get a simple explanation for a specific screen in the app.
 */
export const getScreenExplanation = async (screenName: string): Promise<string> => {
     try {
        const response = await fetch('/api/get-screen-explanation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ screenName }),
        });
        if (!response.ok) throw new Error('API request failed');
        return await response.text();
    } catch (error) {
        console.error(`Error explaining screen "${screenName}" from API:`, error);
        return "Sorry, I couldn't fetch an explanation at this moment. Please try again.";
    }
};

/**
 * Calls the backend to proofread and enhance a piece of text.
 */
export const enhanceText = async (text: string): Promise<string> => {
    if (!text.trim()) return text;
    try {
        const response = await fetch('/api/enhance-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text }),
        });
        if (!response.ok) throw new Error('API request failed');
        return await response.text();
    } catch (error) {
        console.error("Error enhancing text from API:", error);
        return text; // Return original text on error
    }
};

/**
 * Calls the backend to parse natural language text into a structured transaction object.
 */
export const parseTransactionFromText = async (
  text: string, 
  categories: Category[], 
  items: Item[], 
  clients: Client[],
  vendors: Vendor[]
): Promise<PartialTransaction | null> => {
    try {
        const response = await fetch('/api/parse-transaction', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, categories, items, clients, vendors }),
        });
        if (!response.ok) throw new Error('API request failed');
        const parsedData = await response.json();
        if (typeof parsedData === 'object' && parsedData !== null) {
            return parsedData as PartialTransaction;
        }
        console.warn("API returned non-object data:", parsedData);
        return null;
    } catch (error) {
        console.error("Error parsing transaction from API:", error);
        return null;
    }
};

/**
 * Calls the backend to parse natural language text into structured document items (for invoices/quotes).
 */
export const parseDocumentFromText = async (
  text: string, 
  clients: Client[]
): Promise<{ clientName?: string, items?: QuotationItem[] } | null> => {
    try {
        const response = await fetch('/api/parse-document', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, clients }),
        });
        if (!response.ok) throw new Error('API request failed');
        const parsedData = await response.json();
        if (typeof parsedData === 'object' && parsedData !== null) {
            return parsedData as { clientName?: string, items?: QuotationItem[] };
        }
        console.warn("API returned non-object data for document parsing:", parsedData);
        return null;
    } catch (error) {
        console.error("Error parsing document from API:", error);
        return null;
    }
};

/**
 * Calls the backend to parse natural language text into a structured business profile object.
 */
export const parseBusinessFromText = async (text: string): Promise<Partial<Business> | null> => {
    try {
        const response = await fetch('/api/parse-business', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text }),
        });
        if (!response.ok) throw new Error('API request failed');
        const parsedData = await response.json();
        if (typeof parsedData === 'object' && parsedData !== null) {
            return parsedData as Partial<Business>;
        }
        console.warn("API returned non-object data for business parsing:", parsedData);
        return null;
    } catch (error) {
        console.error("Error parsing business from API:", error);
        return null;
    }
};
