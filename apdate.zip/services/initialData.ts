

import { AppData, TransactionType, Item } from '../types';

export const getInitialData = (): AppData => ({
  businesses: [
    { id: '1', ownerId: 'initial-data', name: 'My Freelance Gig', currency: 'GH₵', taxRate: 15, paymentTerms: 15, invoiceNotes: 'Payment due within 15 days. Thank you!', email: 'contact@freelancegig.com', phone: '024 123 4567', address: '123 Anamon Street, Accra', website: 'www.freelancegig.com' },
    { id: '2', ownerId: 'initial-data', name: 'Side Hustle Inc.', currency: '$', taxRate: 0, paymentTerms: 0, invoiceNotes: 'Thank you for your business!', email: 'hello@sidehustle.com' },
  ],
  transactions: [
    { id: '1', ownerId: 'initial-data', businessId: '1', type: TransactionType.INCOME, name: 'Website Design Project', description: 'Final payment for website build for Innovate Corp.', amount: 3500, date: '2024-07-15T10:00:00Z', dueDate: '2024-07-30T10:00:00Z', category: 'Service Revenue', clientId: 'c1', transactionNumber: 'INV-001', nature: 'service', status: 'paid', payments: [{id: 'p1', date: '2024-07-16T10:00:00Z', amount: 3500, method: 'bank_transfer'}], orderStatus: 'completed', fulfillmentType: 'in-house', deliveryMethod: 'digital' },
    { id: '2', ownerId: 'initial-data', businessId: '1', type: TransactionType.EXPENSE, name: 'Adobe Subscription', description: 'Monthly Creative Cloud subscription fee.', amount: 250, date: '2024-07-14T11:00:00Z', category: 'Software & Subscriptions', vendorId: 'v1', transactionNumber: 'EXP-001', nature: 'service', status: 'paid', payments: [] },
    { id: '3', ownerId: 'initial-data', businessId: '1', type: TransactionType.EXPENSE, name: 'Office Rent', description: 'Rent payment for July.', amount: 1500, date: '2024-07-01T09:00:00Z', category: 'Rent & Lease', transactionNumber: 'EXP-002', nature: 'service', status: 'paid', payments: [] },
    { id: '4', ownerId: 'initial-data', businessId: '1', type: TransactionType.INCOME, name: 'Logo Design', description: 'Payment for logo design for Digital Future Co.', amount: 1200, date: '2024-06-25T14:30:00Z', dueDate: '2024-07-10T14:30:00Z', category: 'Service Revenue', clientId: 'c2', transactionNumber: 'INV-002', nature: 'service', status: 'unpaid', payments: [], orderStatus: 'pending', fulfillmentType: 'in-house', deliveryMethod: 'digital' },
    { id: '5', ownerId: 'initial-data', businessId: '1', type: TransactionType.EXPENSE, name: 'Client Lunch', description: 'Entertainment expense for client meeting.', amount: 180, date: '2024-06-22T13:00:00Z', category: 'Meals & Entertainment', transactionNumber: 'EXP-003', nature: 'service', status: 'paid', payments: [] },
    { id: '6', ownerId: 'initial-data', businessId: '2', type: TransactionType.INCOME, name: 'E-book Sales', description: 'Monthly revenue from "The Art of Code" e-book.', amount: 450, date: '2024-07-20T10:00:00Z', dueDate: '2024-07-20T10:00:00Z', category: 'Sales Revenue', transactionNumber: 'INV-001', nature: 'product', quantity: 10, unitPrice: 45, status: 'paid', payments: [], orderStatus: 'completed', fulfillmentType: 'in-house', deliveryMethod: 'digital' },
    { id: '7', ownerId: 'initial-data', businessId: '2', type: TransactionType.EXPENSE, name: 'Web Hosting', description: 'Annual web hosting fee from Hostinger.', amount: 50, date: '2024-07-18T11:00:00Z', category: 'Software & Subscriptions', vendorId: 'v2', transactionNumber: 'EXP-001', nature: 'service', status: 'paid', payments: [] },
    { id: '8', ownerId: 'initial-data', businessId: '1', type: TransactionType.INCOME, name: 'Custom Illustration', description: 'Commissioned art piece for a client', amount: 800, date: '2024-07-22T10:00:00Z', dueDate: '2024-08-05T10:00:00Z', category: 'Service Revenue', clientId: 'c2', transactionNumber: 'INV-003', nature: 'product', status: 'unpaid', payments: [], orderStatus: 'shipped', fulfillmentType: 'in-house', deliveryMethod: 'shipping', trackingNumber: '1Z999AA10123456789', shippingNotes: 'Handle with care. Fragile item.' },
  ],
  settings: {
    theme: 'dark',
    isPinEnabled: false,
    pin: null,
  },
  categories: [
    // Income Categories
    { id: 'inc1', ownerId: 'initial-data', name: 'Sales Revenue', type: TransactionType.INCOME },
    { id: 'inc2', ownerId: 'initial-data', name: 'Service Revenue', type: TransactionType.INCOME },
    { id: 'inc3', ownerId: 'initial-data', name: 'Consulting Fees', type: TransactionType.INCOME },
    { id: 'inc4', ownerId: 'initial-data', name: 'Interest Income', type: TransactionType.INCOME },
    { id: 'inc5', ownerId: 'initial-data', name: 'Other Income', type: TransactionType.INCOME },
    { id: 'inc6', ownerId: 'initial-data', name: 'Owner\'s Equity', type: TransactionType.INCOME },
    
    // Expense Categories (based on standard Chart of Accounts)
    { id: 'exp1', ownerId: 'initial-data', name: 'Cost of Sales', type: TransactionType.EXPENSE, expenseType: 'Cost of Goods Sold' },
    { id: 'exp2', ownerId: 'initial-data', name: 'Advertising & Marketing', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp3', ownerId: 'initial-data', name: 'Bank Charges', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp4', ownerId: 'initial-data', name: 'Meals & Entertainment', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp5', ownerId: 'initial-data', name: 'Office Supplies', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp6', ownerId: 'initial-data', name: 'Professional Fees', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp7', ownerId: 'initial-data', name: 'Rent & Lease', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp8', ownerId: 'initial-data', name: 'Repairs & Maintenance', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp9', ownerId: 'initial-data', name: 'Salaries & Wages', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp10', ownerId: 'initial-data', name: 'Software & Subscriptions', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp11', ownerId: 'initial-data', name: 'Travel', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp12', ownerId: 'initial-data', name: 'Utilities', type: TransactionType.EXPENSE, expenseType: 'Operating Expenses' },
    { id: 'exp13', ownerId: 'initial-data', name: 'Interest Expense', type: TransactionType.EXPENSE, expenseType: 'Other Expenses' },
    { id: 'exp14', ownerId: 'initial-data', name: 'Income Tax', type: TransactionType.EXPENSE, expenseType: 'Other Expenses' },
  ],
  clients: [
    { id: 'c1', ownerId: 'initial-data', name: 'Innovate Corp', email: 'contact@innovate.com' },
    { id: 'c2', ownerId: 'initial-data', name: 'Digital Future Co.', email: 'hello@digitalfuture.com' },
  ],
  vendors: [
    { id: 'v1', ownerId: 'initial-data', name: 'Adobe', service: 'Creative Cloud' },
    { id: 'v2', ownerId: 'initial-data', name: 'Hostinger', service: 'Web Hosting' },
  ],
  items: [
    { id: 'item1', ownerId: 'initial-data', name: 'Website Design Project', type: TransactionType.INCOME, nature: 'service' },
    { id: 'item2', ownerId: 'initial-data', name: 'Logo Design', type: TransactionType.INCOME, nature: 'service' },
    { id: 'item3', ownerId: 'initial-data', name: 'E-book Sales', type: TransactionType.INCOME, nature: 'product', unitPrice: 45 },
    { id: 'item4', ownerId: 'initial-data', name: 'Adobe Subscription', type: TransactionType.EXPENSE, nature: 'service' },
    { id: 'item5', ownerId: 'initial-data', name: 'Office Rent', type: TransactionType.EXPENSE, nature: 'service' },
    { id: 'item6', ownerId: 'initial-data', name: 'Client Lunch', type: TransactionType.EXPENSE, nature: 'service' },
    { id: 'item7', ownerId: 'initial-data', name: 'Web Hosting', type: TransactionType.EXPENSE, nature: 'service' },
    { id: 'item8', ownerId: 'initial-data', name: 'Custom Illustration', type: TransactionType.INCOME, nature: 'product', unitPrice: 800 },
  ],
  quotations: [],
});