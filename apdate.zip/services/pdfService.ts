
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { Business, Client, Quotation, Transaction } from '../types';

// The 'jspdf-autotable' import adds the autoTable method to jsPDF.
// We can cast to 'any' to access it without complex type definitions.

interface PdfInfo {
    document: Transaction | Quotation;
    business: Business;
    client?: Client;
    quote?: Quotation; // For invoices derived from quotes
    type: 'Invoice' | 'Quotation';
}

// Helper to replace special currency symbols that don't work with default PDF fonts
const formatCurrencyForPdf = (currency: string): string => {
    if (currency === 'GH₵') return 'GHS';
    return currency;
}

export const generatePdf = (pdfInfo: PdfInfo) => {
    const { document, business, client, quote, type } = pdfInfo;
    const doc = new jsPDF() as any; // Cast to any to access autoTable
    const pageHeight = doc.internal.pageSize.height;
    const displayCurrency = formatCurrencyForPdf(business.currency);
    
    // 1. Header
    let yPos = 20;
    let textXPos = 20;

    if (business.logo) {
        try {
            // Let jsPDF infer format from data URL. Add logo at x=20.
            doc.addImage(business.logo, undefined, 20, 15, 25, 25, undefined, 'FAST');
            textXPos = 55; // Move all subsequent text to the right
        } catch(e) {
            console.error("Error adding logo to PDF:", e);
        }
    }

    doc.setFontSize(20);
    doc.setFont('helvetica', 'bold');
    doc.text(business.name, textXPos, yPos);
    yPos += 7;
    
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    if (business.address) { doc.text(business.address, textXPos, yPos); yPos += 5; }
    if (business.email) { doc.text(business.email, textXPos, yPos); yPos += 5; }
    if (business.phone) { doc.text(business.phone, textXPos, yPos); yPos += 5; }
    if (business.website) { doc.text(business.website, textXPos, yPos); yPos += 5; }
    
    doc.setFontSize(28);
    doc.setFont('helvetica', 'bold');
    doc.text(type.toUpperCase(), 200, 20, { align: 'right' });
    
    doc.setFontSize(10);
    const docNumber = type === 'Invoice' ? (document as Transaction).transactionNumber : (document as Quotation).quotationNumber;
    doc.text(`${type} Number:`, 150, 30);
    doc.text(docNumber, 200, 30, { align: 'right' });
    doc.text(`Date Issued:`, 150, 35);
    doc.text(new Date(document.date).toLocaleDateString(), 200, 35, { align: 'right' });
    if(type === 'Quotation') {
        doc.text(`Valid Until:`, 150, 40);
        doc.text(new Date((document as Quotation).expiryDate).toLocaleDateString(), 200, 40, { align: 'right' });
    }
    
    let contentYPos = Math.max(yPos, 50);

    doc.setDrawColor(229, 231, 235); // light-border-default
    doc.line(20, contentYPos, 200, contentYPos);
    contentYPos += 10;

    // 2. Bill To
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('BILL TO:', 20, contentYPos);
    contentYPos += 7;
    doc.setFont('helvetica', 'normal');
    doc.text(client?.name || 'N/A', 20, contentYPos);
    contentYPos += 6;
    if(client?.email) doc.text(client.email, 20, contentYPos);

    // 3. Table
    let tableBody: any[][] = [];
    const tableHead = [['Item', 'Description', 'Qty', 'Unit Price', 'Amount']];
    let subtotal = 0;
    
    const items = quote?.items || (document as Quotation).items || [{
        id: document.id,
        name: (document as Transaction).name,
        description: (document as Transaction).description || '',
        quantity: (document as Transaction).quantity || 1,
        unitPrice: (document as Transaction).unitPrice || (document as Transaction).amount,
    }];
    
    items.forEach(item => {
        const itemTotal = item.quantity * item.unitPrice;
        subtotal += itemTotal;
        tableBody.push([
            item.name,
            item.description || '',
            item.quantity.toString(),
            `${displayCurrency} ${item.unitPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2})}`,
            `${displayCurrency} ${itemTotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2})}`
        ]);
    });
    
    doc.autoTable({
        head: tableHead,
        body: tableBody,
        startY: contentYPos + 10,
        theme: 'grid',
        headStyles: {
            fillColor: [37, 99, 235], // accent color
            textColor: 255,
            fontStyle: 'bold'
        },
        styles: {
            cellPadding: 2.5,
            fontSize: 10
        },
        columnStyles: {
            4: { halign: 'right' }
        }
    });
    
    // 4. Totals
    let finalY = doc.lastAutoTable.finalY + 10;
    const taxRate = 'taxRate' in document ? document.taxRate : business.taxRate;
    const taxAmount = subtotal * (taxRate / 100);
    const total = subtotal + taxAmount;
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'normal');
    doc.text('Subtotal:', 150, finalY);
    doc.text(`${displayCurrency} ${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2})}`, 200, finalY, { align: 'right' });
    
    doc.text(`Tax (${taxRate}%):`, 150, finalY + 7);
    doc.text(`${displayCurrency} ${taxAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2})}`, 200, finalY + 7, { align: 'right' });
    
    doc.setFont('helvetica', 'bold');
    doc.text('TOTAL:', 150, finalY + 14);
    doc.text(`${displayCurrency} ${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2})}`, 200, finalY + 14, { align: 'right' });

    // 5. Notes
    finalY += 30;
    const notes = 'notes' in document && document.notes ? document.notes : business.invoiceNotes;
    if (notes) {
        doc.setFontSize(10);
        doc.setFont('helvetica', 'bold');
        doc.text('Notes:', 20, finalY);
        doc.setFont('helvetica', 'normal');
        const splitNotes = doc.splitTextToSize(notes, 180);
        doc.text(splitNotes, 20, finalY + 5);
    }
    
    // 6. Footer
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text(`Generated by Apdate Smart Bookkeeping`, 105, pageHeight - 10, { align: 'center' });
    
    doc.save(`${type}_${docNumber}.pdf`);
};