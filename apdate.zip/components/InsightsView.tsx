
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Transaction, TransactionType, Category, expenseTypes, Client, Vendor, Item } from '../types';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { generateFinancialInsightStream, getTermExplanation } from '../services/geminiService';
import { InfoIcon } from './icons/InfoIcon';
import AIExplainModal from './AIExplainModal';
import { useAppContext } from '../context/AppContext';


// The 'jspdf-autotable' import adds the autoTable method to jsPDF.
// We can cast to 'any' to access it without complex type definitions.

type Period = 'monthly' | 'quarterly' | 'yearly';
type InsightTab = 'reports' | 'charts' | 'ratios' | 'analysis';
type ReportType = 'pnl' | 'balanceSheet' | 'cashFlow' | 'customerReport' | 'vendorReport' | 'itemReport';


const TABS: { id: InsightTab, label: string }[] = [
    { id: 'reports', label: 'Reports' },
    { id: 'charts', label: 'Charts' },
    { id: 'ratios', label: 'Ratios' },
    { id: 'analysis', label: 'AI Analysis' },
];

const COLORS = ['#2563EB', '#D92D20', '#057A55', '#D97706', '#9333EA', '#7C2D12', '#0891B2', '#64748B'];

const SegmentedControl: React.FC<{
    options: { value: string; label: string; }[];
    value: string;
    onChange: (value: string) => void;
}> = ({ options, value, onChange }) => (
    <div className="flex w-full rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset p-1">
        {options.map(opt => (
            <button
                key={opt.value}
                type="button"
                onClick={() => onChange(opt.value)}
                className={`w-full p-2.5 rounded-lg font-semibold transition-all duration-300 text-sm focus:outline-none
                    ${value === opt.value
                        ? 'bg-light-bg-subtle dark:bg-dark-bg-subtle text-light-fg-default dark:text-dark-fg-default shadow'
                        : 'text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default'}`
                }
            >
                {opt.label}
            </button>
        ))}
    </div>
);


const InsightsView: React.FC = () => {
    const { activeBusiness, appData, dataForActiveBusiness } = useAppContext();
    const { visibleTransactions } = dataForActiveBusiness;
    const { categories: allCategories, clients, vendors, items } = appData;
    const currency = activeBusiness?.currency || '';
    
    const [activeTab, setActiveTab] = useState<InsightTab>('reports');
    const [reportType, setReportType] = useState<ReportType>('pnl');
    const [period, setPeriod] = useState<Period>('monthly');
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [explainingTerm, setExplainingTerm] = useState<string | null>(null);

    const isDark = document.documentElement.classList.contains('dark');

    const { filteredTransactions, transactionsBeforePeriod, periodStart, periodEnd } = useMemo(() => {
        const newPeriodStart = new Date(selectedDate);
        const newPeriodEnd = new Date(selectedDate);

        if (period === 'monthly') {
            newPeriodStart.setDate(1);
            newPeriodStart.setHours(0, 0, 0, 0);
            newPeriodEnd.setMonth(newPeriodStart.getMonth() + 1);
            newPeriodEnd.setDate(0);
            newPeriodEnd.setHours(23, 59, 59, 999);
        } else if (period === 'yearly') {
            newPeriodStart.setMonth(0, 1);
            newPeriodStart.setHours(0, 0, 0, 0);
            newPeriodEnd.setFullYear(newPeriodStart.getFullYear() + 1);
            newPeriodEnd.setMonth(0, 0);
            newPeriodEnd.setHours(23, 59, 59, 999);
        } else if (period === 'quarterly') {
            const quarter = Math.floor(newPeriodStart.getMonth() / 3);
            newPeriodStart.setMonth(quarter * 3, 1);
            newPeriodStart.setHours(0, 0, 0, 0);
            newPeriodEnd.setMonth(newPeriodStart.getMonth() + 3);
            newPeriodEnd.setDate(0);
            newPeriodEnd.setHours(23, 59, 59, 999);
        }

        const filtered = visibleTransactions.filter(t => {
            const tDate = new Date(t.date);
            return tDate >= newPeriodStart && tDate <= newPeriodEnd;
        });

        const before = visibleTransactions.filter(t => new Date(t.date) < newPeriodStart);

        return { filteredTransactions: filtered, transactionsBeforePeriod: before, periodStart: newPeriodStart, periodEnd: newPeriodEnd };
    }, [visibleTransactions, period, selectedDate]);
    
    const financialData = useMemo(() => {
        // P&L Calculations
        const incomeByCategory: { [key: string]: number } = {};
        const expensesGrouped: { [key: string]: { total: number, categories: { [key: string]: number } } } = {};
        let totalIncome = 0;
        let totalExpense = 0;

        filteredTransactions.forEach(t => {
            if (t.type === TransactionType.INCOME) {
                totalIncome += t.amount;
                incomeByCategory[t.category] = (incomeByCategory[t.category] || 0) + t.amount;
            } else {
                totalExpense += t.amount;
                const categoryDetails = allCategories.find(c => c.name === t.category && c.type === 'expense');
                const expenseType = categoryDetails?.expenseType || 'Other Expenses';
                
                if (!expensesGrouped[expenseType]) {
                    expensesGrouped[expenseType] = { total: 0, categories: {} };
                }
                expensesGrouped[expenseType].total += t.amount;
                expensesGrouped[expenseType].categories[t.category] = (expensesGrouped[expenseType].categories[t.category] || 0) + t.amount;
            }
        });
        const netProfit = totalIncome - totalExpense;

        // Balance Sheet & Cash Flow Calculations
        let retainedEarnings = 0;
        transactionsBeforePeriod.forEach(t => {
            retainedEarnings += t.type === TransactionType.INCOME ? t.amount : -t.amount;
        });
        
        const totalCash = retainedEarnings + netProfit; // Ending cash position

        // Detailed Reports Calculations
        const customerReportData = clients.map(client => {
            const clientTransactions = filteredTransactions.filter(t => t.clientId === client.id && t.type === TransactionType.INCOME);
            const totalRevenue = clientTransactions.reduce((sum, t) => sum + t.amount, 0);
            return {
                clientId: client.id,
                clientName: client.name,
                totalRevenue,
                transactionCount: clientTransactions.length,
            }
        }).filter(c => c.totalRevenue > 0)
        .sort((a,b) => b.totalRevenue - a.totalRevenue);

        const vendorReportData = vendors.map(vendor => {
            const vendorTransactions = filteredTransactions.filter(t => t.vendorId === vendor.id && t.type === TransactionType.EXPENSE);
            const totalSpent = vendorTransactions.reduce((sum, t) => sum + t.amount, 0);
            return {
                vendorId: vendor.id,
                vendorName: vendor.name,
                totalSpent,
                transactionCount: vendorTransactions.length,
            }
        }).filter(v => v.totalSpent > 0)
        .sort((a,b) => b.totalSpent - a.totalSpent);
        
        const itemReportData = items.map(item => {
            const itemTransactions = filteredTransactions.filter(t => t.name === item.name);
            const totalIncome = itemTransactions.filter(t => t.type === TransactionType.INCOME).reduce((sum, t) => sum + t.amount, 0);
            const totalExpense = itemTransactions.filter(t => t.type === TransactionType.EXPENSE).reduce((sum, t) => sum + t.amount, 0);
            return {
                itemId: item.id,
                itemName: item.name,
                itemType: item.type,
                totalIncome,
                totalExpense,
                transactionCount: itemTransactions.length,
            }
        }).filter(i => i.transactionCount > 0)
        .sort((a,b) => (b.totalIncome + b.totalExpense) - (a.totalIncome + a.totalExpense));
        
        return {
            pnl: { incomeByCategory, expensesGrouped, totalIncome, totalExpense, netProfit },
            balanceSheet: { totalCash, retainedEarnings, currentPeriodEarnings: netProfit },
            cashFlow: { beginningCash: retainedEarnings, cashFromOperations: netProfit, endingCash: totalCash },
            customerReport: customerReportData,
            vendorReport: vendorReportData,
            itemReport: itemReportData,
        };
    }, [filteredTransactions, transactionsBeforePeriod, allCategories, clients, vendors, items]);
    
    const handleDateChange = (increment: number) => {
        const newDate = new Date(selectedDate);
        if (period === 'monthly') newDate.setMonth(newDate.getMonth() + increment);
        if (period === 'yearly') newDate.setFullYear(newDate.getFullYear() + increment);
        if (period === 'quarterly') newDate.setMonth(newDate.getMonth() + (increment * 3));
        setSelectedDate(newDate);
    };

    const formatDateLabel = () => {
        if (period === 'monthly') return selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        if (period === 'yearly') return selectedDate.getFullYear().toString();
        if (period === 'quarterly') {
            const quarter = Math.floor(selectedDate.getMonth() / 3) + 1;
            return `Q${quarter} ${selectedDate.getFullYear()}`;
        }
    };
    
    const downloadPdf = () => {
        const doc = new jsPDF() as any;
        const pnlData = financialData.pnl;
        const bsData = financialData.balanceSheet;
        const cfData = financialData.cashFlow;
        const displayCurrency = currency === 'GH₵' ? 'GHS' : currency;

        doc.setFontSize(12);
        doc.text(`Currency: ${displayCurrency}`, 14, 15);
        let finalY = 22;
        
        if (reportType === 'pnl') {
            doc.setFontSize(18);
            doc.text(`Profit & Loss Statement - ${formatDateLabel()}`, 14, finalY);
            finalY += 15;
            doc.autoTable({ startY: finalY, head: [['Income', 'Amount']], body: [...Object.entries(pnlData.incomeByCategory).map(([c, a]) => [c, a.toLocaleString()]), ['Total Income', pnlData.totalIncome.toLocaleString()]], headStyles: {fillColor: '#057A55'}, foot: [['Total Income', pnlData.totalIncome.toLocaleString()]], footStyles: {fontStyle: 'bold' as const} });
            finalY = doc.lastAutoTable.finalY + 10;
            
            const expenseRows = Object.entries(pnlData.expensesGrouped).flatMap(([group, data]) => [
                [{content: group, styles: {fontStyle: 'bold' as const}}],
                ...Object.entries(data.categories).map(([cat, amt]) => [`  ${cat}`, amt.toLocaleString()])
            ]);
            doc.autoTable({ startY: finalY, head: [['Expenses', 'Amount']], body: expenseRows, headStyles: {fillColor: '#D92D20'}, foot: [['Total Expenses', pnlData.totalExpense.toLocaleString()]], footStyles: {fontStyle: 'bold' as const} });
            finalY = doc.lastAutoTable.finalY;
            doc.setFontSize(14);
            doc.setFont('helvetica', 'bold');
            doc.text("Net Profit:", 14, finalY + 15);
            doc.text(`${displayCurrency} ${pnlData.netProfit.toLocaleString()}`, 200, finalY + 15, { align: 'right' });
        } else if (reportType === 'balanceSheet') {
            doc.setFontSize(18);
            doc.text(`Balance Sheet as at ${periodEnd.toLocaleDateString()}`, 14, finalY);
            finalY += 15;
            doc.autoTable({ startY: finalY, head: [['Assets', 'Amount']], body: [['Cash', bsData.totalCash.toLocaleString()]], foot: [['Total Assets', bsData.totalCash.toLocaleString()]], footStyles: {fontStyle: 'bold' as const} });
            finalY = doc.lastAutoTable.finalY + 10;
            doc.autoTable({ startY: finalY, head: [['Equity', 'Amount']], body: [['Retained Earnings', bsData.retainedEarnings.toLocaleString()], ['Current Period Earnings', bsData.currentPeriodEarnings.toLocaleString()]], foot: [['Total Equity', bsData.totalCash.toLocaleString()]], footStyles: {fontStyle: 'bold' as const} });
        } else if (reportType === 'cashFlow') {
            doc.setFontSize(18);
            doc.text(`Cash Flow Statement - ${formatDateLabel()}`, 14, finalY);
            finalY += 15;
            doc.autoTable({ startY: finalY, head: [['Cash Flow from Operations', 'Amount']], body: [['Net Income', cfData.cashFromOperations.toLocaleString()], ['Net Cash from Operations', cfData.cashFromOperations.toLocaleString()]] });
            finalY = doc.lastAutoTable.finalY + 10;
            doc.autoTable({ startY: finalY, body: [['Beginning Cash Balance', cfData.beginningCash.toLocaleString()], ['Net Change in Cash', cfData.cashFromOperations.toLocaleString()], ['Ending Cash Balance', cfData.endingCash.toLocaleString()]], bodyStyles: {fontStyle: 'bold' as const} });
        } else if (reportType === 'customerReport') {
            doc.setFontSize(18);
            doc.text(`Customer Revenue Report - ${formatDateLabel()}`, 14, finalY);
            finalY += 15;
            const body = financialData.customerReport.map(c => [c.clientName, c.transactionCount, `${displayCurrency} ${c.totalRevenue.toLocaleString()}`]);
            doc.autoTable({ startY: finalY, head: [['Client', 'Transactions', 'Total Revenue']], body: body, headStyles: { fillColor: '#2563EB' } });
        } else if (reportType === 'vendorReport') {
            doc.setFontSize(18);
            doc.text(`Vendor Expense Report - ${formatDateLabel()}`, 14, finalY);
            finalY += 15;
            const body = financialData.vendorReport.map(v => [v.vendorName, v.transactionCount, `${displayCurrency} ${v.totalSpent.toLocaleString()}`]);
            doc.autoTable({ startY: finalY, head: [['Vendor', 'Transactions', 'Total Spent']], body: body, headStyles: { fillColor: '#2563EB' } });
        } else if (reportType === 'itemReport') {
            doc.setFontSize(18);
            doc.text(`Products & Services Report - ${formatDateLabel()}`, 14, finalY);
            finalY += 15;
            const body = financialData.itemReport.map(i => [i.itemName, i.itemType, i.transactionCount, `${displayCurrency} ${i.totalIncome.toLocaleString()}`, `${displayCurrency} ${i.totalExpense.toLocaleString()}`]);
            doc.autoTable({ startY: finalY, head: [['Product/Service', 'Type', 'Transactions', 'Total Income', 'Total Expense']], body: body, headStyles: { fillColor: '#2563EB' } });
        }
        
        doc.save(`${reportType}_${formatDateLabel().replace(' ', '_')}.pdf`);
    };

    const ReportRow: React.FC<{label: string, value: number, isTotal?: boolean, level?: number, term?: string}> = ({label, value, isTotal = false, level = 0, term}) => (
        <tr className={`${isTotal ? 'font-bold bg-light-bg-inset dark:bg-dark-bg-inset' : ''} border-b border-light-border-default dark:border-dark-border-default last:border-b-0`}>
            <td className={`py-3 pl-${2 + (level * 4)}`}>
                <div className="flex items-center">
                    <span>{label}</span>
                    {term && <button onClick={() => setExplainingTerm(term)} className="ml-2 text-accent"><InfoIcon /></button>}
                </div>
            </td>
            <td className="text-right py-3 pr-2">{currency} {value.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
        </tr>
    );

    const PnLReport = () => {
        const { incomeByCategory, expensesGrouped, totalIncome, totalExpense, netProfit } = financialData.pnl;
        return(
            <>
                <h3 className="font-bold text-lg text-light-income-fg dark:text-dark-income-fg">Income</h3>
                <table className="w-full my-2 text-sm"><tbody>
                    {Object.entries(incomeByCategory).map(([cat, amt]) => <ReportRow key={cat} label={cat} value={amt} level={1}/>)}
                    <ReportRow label="Total Income" value={totalIncome} isTotal/>
                </tbody></table>
                
                <h3 className="font-bold text-lg text-light-expense-fg dark:text-dark-expense-fg mt-4">Expenses</h3>
                <table className="w-full my-2 text-sm"><tbody>
                    {expenseTypes.map(type => {
                        const group = expensesGrouped[type];
                        if (!group) return null;
                        return (
                            <React.Fragment key={type}>
                                <tr className="font-semibold text-light-fg-subtle dark:text-dark-fg-subtle"><td colSpan={2} className="pt-3 pb-1">{type}</td></tr>
                                {Object.entries(group.categories).map(([cat, amt]) => <ReportRow key={cat} label={cat} value={amt} level={1} />)}
                            </React.Fragment>
                        );
                    })}
                     <ReportRow label="Total Expenses" value={totalExpense} isTotal/>
                </tbody></table>

                <table className="w-full mt-4 text-sm"><tbody>
                    <ReportRow label="Net Profit" value={netProfit} isTotal term="Net Profit"/>
                </tbody></table>
            </>
        );
    }
    
    const BalanceSheetReport = () => {
        const { totalCash, retainedEarnings, currentPeriodEarnings } = financialData.balanceSheet;
        return (
            <>
                <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default">Assets</h3>
                <table className="w-full my-2 text-sm"><tbody>
                    <ReportRow label="Cash" value={totalCash} level={1} term="Assets" />
                    <ReportRow label="Total Assets" value={totalCash} isTotal />
                </tbody></table>
                
                <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default mt-4">Liabilities & Equity</h3>
                <p className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle px-2 py-1">Note: Liabilities (e.g., loans) are not yet tracked.</p>
                <table className="w-full my-2 text-sm"><tbody>
                    <tr className="font-semibold text-light-fg-subtle dark:text-dark-fg-subtle"><td colSpan={2} className="pt-2">Equity</td></tr>
                    <ReportRow label="Retained Earnings" value={retainedEarnings} level={1} term="Retained Earnings" />
                    <ReportRow label="Current Period Earnings" value={currentPeriodEarnings} level={1} />
                    <ReportRow label="Total Equity" value={totalCash} isTotal />
                </tbody></table>

                 <table className="w-full mt-4 text-sm"><tbody>
                    <ReportRow label="Total Liabilities & Equity" value={totalCash} isTotal />
                </tbody></table>
            </>
        )
    };
    
    const CashFlowReport = () => {
        const { beginningCash, cashFromOperations, endingCash } = financialData.cashFlow;
        return (
             <>
                <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default">Cash Flow from Operating Activities</h3>
                 <p className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle px-2 py-1">Note: Non-cash adjustments are not yet tracked.</p>
                <table className="w-full my-2 text-sm"><tbody>
                    <ReportRow label="Net Income" value={cashFromOperations} level={1} />
                    <ReportRow label="Net Cash from Operations" value={cashFromOperations} isTotal term="Cash Flow from Operating Activities" />
                </tbody></table>

                <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default mt-4">Summary</h3>
                <table className="w-full my-2 text-sm"><tbody>
                     <ReportRow label="Beginning Cash Balance" value={beginningCash} />
                     <ReportRow label="Net Change in Cash" value={cashFromOperations} />
                     <ReportRow label="Ending Cash Balance" value={endingCash} isTotal />
                </tbody></table>
            </>
        )
    };

    const CustomerReport = () => (
        <>
            <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default">Customer Revenue Report</h3>
            <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle mb-2">Revenue generated from each client in this period.</p>
            <table className="w-full my-2 text-sm">
                <thead className="border-b-2 border-light-border-default dark:border-dark-border-default">
                    <tr className="text-left font-semibold">
                        <th className="py-2 pl-2">Client</th>
                        <th className="py-2 text-center">Transactions</th>
                        <th className="py-2 pr-2 text-right">Total Revenue</th>
                    </tr>
                </thead>
                <tbody>
                    {financialData.customerReport.length === 0 ? (
                        <tr><td colSpan={3} className="text-center py-4 text-light-fg-subtle dark:text-dark-fg-subtle">No client revenue in this period.</td></tr>
                    ) : (
                        financialData.customerReport.map(c => (
                            <tr key={c.clientId} className="border-b border-light-border-default dark:border-dark-border-default last:border-b-0">
                                <td className="py-3 pl-2 font-medium">{c.clientName}</td>
                                <td className="py-3 text-center">{c.transactionCount}</td>
                                <td className="py-3 pr-2 text-right text-light-income-fg dark:text-dark-income-fg font-semibold">{currency} {c.totalRevenue.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </>
    );

    const VendorReport = () => (
        <>
            <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default">Vendor Expense Report</h3>
            <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle mb-2">Total amount spent with each vendor in this period.</p>
            <table className="w-full my-2 text-sm">
                <thead className="border-b-2 border-light-border-default dark:border-dark-border-default">
                    <tr className="text-left font-semibold">
                        <th className="py-2 pl-2">Vendor</th>
                        <th className="py-2 text-center">Transactions</th>
                        <th className="py-2 pr-2 text-right">Total Spent</th>
                    </tr>
                </thead>
                <tbody>
                    {financialData.vendorReport.length === 0 ? (
                        <tr><td colSpan={3} className="text-center py-4 text-light-fg-subtle dark:text-dark-fg-subtle">No vendor expenses in this period.</td></tr>
                    ) : (
                        financialData.vendorReport.map(v => (
                            <tr key={v.vendorId} className="border-b border-light-border-default dark:border-dark-border-default last:border-b-0">
                                <td className="py-3 pl-2 font-medium">{v.vendorName}</td>
                                <td className="py-3 text-center">{v.transactionCount}</td>
                                <td className="py-3 pr-2 text-right text-light-expense-fg dark:text-dark-expense-fg font-semibold">{currency} {v.totalSpent.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </>
    );

    const ItemReport = () => (
        <>
            <h3 className="font-bold text-lg text-light-fg-default dark:text-dark-fg-default">Products & Services Report</h3>
            <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle mb-2">Performance of each product or service in this period.</p>
            <table className="w-full my-2 text-sm">
                <thead className="border-b-2 border-light-border-default dark:border-dark-border-default">
                    <tr className="text-left font-semibold">
                        <th className="py-2 pl-2">Item</th>
                        <th className="py-2 text-center">Transactions</th>
                        <th className="py-2 pr-2 text-right">Total Income</th>
                        <th className="py-2 pr-2 text-right">Total Expense</th>
                    </tr>
                </thead>
                <tbody>
                    {financialData.itemReport.length === 0 ? (
                        <tr><td colSpan={4} className="text-center py-4 text-light-fg-subtle dark:text-dark-fg-subtle">No item data in this period.</td></tr>
                     ) : (
                        financialData.itemReport.map(i => (
                            <tr key={i.itemId} className="border-b border-light-border-default dark:border-dark-border-default last:border-b-0">
                                <td className="py-3 pl-2 font-medium">
                                    {i.itemName}
                                    <span className={`block text-xs capitalize ${i.itemType === 'income' ? 'text-light-income-fg dark:text-dark-income-fg' : 'text-light-expense-fg dark:text-dark-expense-fg'}`}>{i.itemType}</span>
                                </td>
                                <td className="py-3 text-center">{i.transactionCount}</td>
                                <td className="py-3 pr-2 text-right text-light-income-fg dark:text-dark-income-fg">{i.totalIncome > 0 ? `${currency} ${i.totalIncome.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}` : '-'}</td>
                                <td className="py-3 pr-2 text-right text-light-expense-fg dark:text-dark-expense-fg">{i.totalExpense > 0 ? `${currency} ${i.totalExpense.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}` : '-'}</td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </>
    );

    const ReportsTab = () => (
        <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl p-4">
            <div className="mb-4 grid grid-cols-2 gap-2">
                <select
                    value={reportType}
                    onChange={e => setReportType(e.target.value as ReportType)}
                    className="w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent focus:border-accent border-2 rounded-xl py-3 px-4 focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default"
                >
                    <optgroup label="Financial Statements">
                        <option value="pnl">Profit & Loss</option>
                        <option value="balanceSheet">Balance Sheet</option>
                        <option value="cashFlow">Cash Flow</option>
                    </optgroup>
                    <optgroup label="Detailed Reports">
                        <option value="customerReport">Customer Report</option>
                        <option value="vendorReport">Vendor Report</option>
                        <option value="itemReport">Products & Services</option>
                    </optgroup>
                </select>
                <button onClick={downloadPdf} className="bg-accent text-accent-fg font-bold py-2 px-4 rounded-xl hover:opacity-90 transition-opacity">Download PDF</button>
            </div>
            
            {reportType === 'pnl' && <PnLReport />}
            {reportType === 'balanceSheet' && <BalanceSheetReport />}
            {reportType === 'cashFlow' && <CashFlowReport />}
            {reportType === 'customerReport' && <CustomerReport />}
            {reportType === 'vendorReport' && <VendorReport />}
            {reportType === 'itemReport' && <ItemReport />}
        </div>
    );
    
    const ChartsTab = () => {
        const expenseChartData = Object.entries(financialData.pnl.expensesGrouped).flatMap(([groupName, groupData]) => 
            Object.entries(groupData.categories).map(([name, value]) => ({ name, value }))
        );

        return (
            <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl p-4">
                <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default mb-4 text-center">Expense Breakdown</h3>
                {expenseChartData.length > 0 ? (
                    <div style={{ width: '100%', height: 300 }}>
                        <ResponsiveContainer>
                            <PieChart>
                                <Pie data={expenseChartData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                                    {expenseChartData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                                </Pie>
                                <RechartsTooltip 
                                    formatter={(value: number) => `${currency} ${value.toLocaleString()}`} 
                                    contentStyle={{ 
                                        backgroundColor: isDark ? '#1F2937' : '#FFFFFF',
                                        border: '1px solid',
                                        borderColor: isDark ? '#374151' : '#E5E7EB',
                                        borderRadius: '0.75rem',
                                    }}
                                />
                                <Legend wrapperStyle={{fontSize: "0.8rem", color: isDark ? '#9CA3AF' : '#6B7280'}}/>
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                ) : <p className="text-center text-light-fg-subtle dark:text-dark-fg-subtle py-10">No expense data for this period.</p>}
            </div>
        );
    };
    
    const RatiosTab = () => {
        const { totalIncome, netProfit } = financialData.pnl;
        const netProfitMargin = totalIncome > 0 ? ((netProfit / totalIncome) * 100).toFixed(2) : 0;
        return (
            <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl p-4 space-y-4">
                 <div className="flex justify-between items-center p-4 rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset">
                    <div>
                        <h4 className="font-semibold text-light-fg-default dark:text-dark-fg-default">Net Profit Margin</h4>
                        <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">Measures profitability</p>
                    </div>
                    <p className={`text-2xl font-bold ${Number(netProfitMargin) >= 0 ? 'text-light-income-fg dark:text-dark-income-fg' : 'text-light-expense-fg dark:text-dark-expense-fg'}`}>{netProfitMargin}%</p>
                </div>
                 <div className="flex justify-between items-center p-4 rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset">
                    <div>
                        <h4 className="font-semibold text-light-fg-default dark:text-dark-fg-default">Total Income</h4>
                        <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">All revenue generated</p>
                    </div>
                    <p className="text-2xl font-bold text-light-income-fg dark:text-dark-income-fg">{currency} {totalIncome.toLocaleString()}</p>
                </div>
                 <div className="flex justify-between items-center p-4 rounded-xl bg-light-bg-inset dark:bg-dark-bg-inset">
                    <div>
                        <h4 className="font-semibold text-light-fg-default dark:text-dark-fg-default">Total Expenses</h4>
                        <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">All costs incurred</p>
                    </div>
                    <p className="text-2xl font-bold text-light-expense-fg dark:text-dark-expense-fg">{currency} {financialData.pnl.totalExpense.toLocaleString()}</p>
                </div>
            </div>
        );
    };
    
    const AnalysisTab = () => {
        const [analysis, setAnalysis] = useState('');
        const [isLoading, setIsLoading] = useState(false);
        const hasFetched = useRef(false);

        const getAnalysis = async () => {
            if (isLoading || !filteredTransactions.length) return;
            setIsLoading(true);
            hasFetched.current = true;
            try {
                const prompt = `Based on the following profit and loss data for a small business for the period of ${formatDateLabel()}, provide a concise financial analysis. The currency is ${currency}. Highlight the largest expense category group (e.g., Operating Expenses), comment on the profitability, and provide one actionable tip for improvement based on the data.\n\n${JSON.stringify(financialData.pnl)}`;
                const stream = await generateFinancialInsightStream(prompt, [], currency, [], []); // Pass empty arrays as context is in prompt
                
                let fullResponse = '';
                for await (const chunk of stream) {
                    fullResponse += chunk.text;
                    setAnalysis(fullResponse);
                }
            } catch (e) {
                setAnalysis("Sorry, I couldn't generate an analysis. Please try again.");
            } finally {
                setIsLoading(false);
            }
        };

        useEffect(() => {
            if(!hasFetched.current && filteredTransactions.length > 0) getAnalysis();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }, [filteredTransactions]);


        return (
            <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl p-4 min-h-[300px]">
                {!filteredTransactions.length ? (
                    <p className="text-center text-light-fg-subtle dark:text-dark-fg-subtle py-10">No data for this period to analyze.</p>
                ) : isLoading ? (
                    <div className="flex justify-center items-center h-full pt-10">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent"></div>
                    </div>
                ) : (
                    <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap font-sans text-light-fg-default dark:text-dark-fg-default" style={{whiteSpace: 'pre-wrap'}}>{analysis}</div>
                )}
            </div>
        );
    };

    return (
        <>
            <div className="space-y-4">
                <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-xl p-2">
                    <div className="flex items-center justify-between">
                        <button onClick={() => handleDateChange(-1)} className="p-2 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-accent">{'<'}</button>
                        <div className="flex-grow text-center">
                            <select value={period} onChange={e => setPeriod(e.target.value as Period)} className="bg-transparent font-semibold text-center focus:outline-none text-light-fg-default dark:text-dark-fg-default dark:bg-dark-bg-subtle">
                                <option value="monthly">Monthly</option>
                                <option value="quarterly">Quarterly</option>
                                <option value="yearly">Yearly</option>
                            </select>
                            <div className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">{formatDateLabel()}</div>
                        </div>
                        <button onClick={() => handleDateChange(1)} className="p-2 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-accent">{'>'}</button>
                    </div>
                </div>

                <SegmentedControl
                    value={activeTab}
                    onChange={(val) => setActiveTab(val as InsightTab)}
                    options={TABS.map(tab => ({ value: tab.id, label: tab.label }))}
                />
                
                {activeTab === 'reports' && <ReportsTab />}
                {activeTab === 'charts' && <ChartsTab />}
                {activeTab === 'ratios' && <RatiosTab />}
                {activeTab === 'analysis' && <AnalysisTab />}
            </div>

            {explainingTerm && (
                <AIExplainModal
                    term={explainingTerm}
                    onClose={() => setExplainingTerm(null)}
                />
            )}
        </>
    );
};

export default InsightsView;
