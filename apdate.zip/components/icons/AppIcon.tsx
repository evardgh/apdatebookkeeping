import React from 'react';

export const AppIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="100" height="100" rx="22" fill="url(#paint0_linear_app_icon)"/>
        <defs>
            <linearGradient id="paint0_linear_app_icon" x1="50" y1="0" x2="50" y2="100" gradientUnits="userSpaceOnUse">
                <stop stopColor="#F9FAFB"/>
                <stop offset="1" stopColor="#F3F4F6"/>
            </linearGradient>
            <linearGradient id="paint1_linear_app_icon" x1="50" y1="21.3218" x2="50" y2="65.5343" gradientUnits="userSpaceOnUse">
                <stop stopColor="#3B82F6"/>
                <stop offset="1" stopColor="#2563EB"/>
            </linearGradient>
        </defs>
        <g fill="url(#paint1_linear_app_icon)">
            <path d="M68.5919 51.5C68.5919 55.4437 67.243 58.7687 64.5451 61.475C61.8472 64.1812 58.2045 65.5343 53.6169 65.5343H46.3831C41.7955 65.5343 38.1528 64.1812 35.4549 61.475C32.757 58.7687 31.4081 55.4437 31.4081 51.5V49.0343H68.5919V51.5Z"/>
            <path d="M72.4081 45.4156H27.5919C27.5919 38.0781 30.4357 32.2281 36.1234 27.8656C41.8111 23.5031 46.9924 21.3218 50 21.3218C53.0076 21.3218 58.1889 23.5031 63.8766 27.8656C69.5643 32.2281 72.4081 38.0781 72.4081 45.4156Z"/>
        </g>
    </svg>
);