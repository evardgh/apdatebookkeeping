
import React, { useMemo } from 'react';
import { Transaction, Client, Vendor } from '../types';
import { PlusIcon } from './icons/PlusIcon';
import StatusBadge from './StatusBadge';
import { ClipboardListIcon } from './icons/ClipboardListIcon';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import { useAppContext } from '../context/AppContext';

interface OrdersViewProps {
  onEditOrder: (order: Transaction) => void;
  onAddOrder: () => void;
  onAddOrderByVoice: () => void;
}

const StatCard: React.FC<{ title: string; value: string; }> = ({ title, value }) => (
  <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-3 rounded-xl flex-1">
    <h3 className="text-xs font-medium text-light-fg-subtle dark:text-dark-fg-subtle">{title}</h3>
    <p className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default">{value}</p>
  </div>
);


const OrderItem: React.FC<{ order: Transaction; currency: string; clientName: string, onClick: () => void }> = ({ order, currency, clientName, onClick }) => {
    
    const OrderStatusBadge: React.FC<{status?: string}> = ({ status }) => {
        if (!status) return null;
        let colorClasses = 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
        switch (status) {
            case 'completed':
                colorClasses = 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'; break;
            case 'pending':
                colorClasses = 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300'; break;
            case 'in_progress':
            case 'shipped':
            case 'ready_for_pickup':
                 colorClasses = 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'; break;
            case 'cancelled':
                 colorClasses = 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'; break;
        }
        return <span className={`font-semibold rounded-full capitalize px-2 py-0.5 text-xs ${colorClasses}`}>{status.replace(/_/g, ' ')}</span>
    }

    return (
        <li onClick={onClick} className="p-4 bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl cursor-pointer hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors">
            <div className="flex items-start justify-between">
                <div className="truncate pr-4">
                    <p className="font-semibold text-light-fg-default dark:text-dark-fg-default truncate">{order.name}</p>
                    <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">
                        {new Date(order.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        {' • '}
                        {clientName}
                    </p>
                    <div className="mt-2 flex items-center gap-2">
                        <StatusBadge status={order.status} />
                        <OrderStatusBadge status={order.orderStatus} />
                    </div>
                </div>
                <div className="flex flex-col items-end flex-shrink-0 ml-2">
                    <p className="font-semibold text-light-income-fg dark:text-dark-income-fg">
                       {currency} {order.amount.toLocaleString()}
                    </p>
                </div>
            </div>
        </li>
    );
};

const OrdersView: React.FC<OrdersViewProps> = ({ onEditOrder, onAddOrder, onAddOrderByVoice }) => {
    const { activeBusiness, dataForActiveBusiness } = useAppContext();
    const { visibleTransactions, clients } = dataForActiveBusiness;
    const currency = activeBusiness?.currency || '';

    const orders = useMemo(() => {
        return visibleTransactions.filter(t => t.orderStatus).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [visibleTransactions]);
    
    const { totalSales, averageOrderValue, openOrders } = useMemo(() => {
        const completedOrders = orders.filter(o => o.orderStatus === 'completed');
        const sales = completedOrders.reduce((sum, o) => sum + o.amount, 0);
        const avg = completedOrders.length > 0 ? sales / completedOrders.length : 0;
        const open = orders.filter(o => o.orderStatus !== 'completed' && o.orderStatus !== 'cancelled').length;

        return {
            totalSales: sales,
            averageOrderValue: avg,
            openOrders: open,
        }
    }, [orders]);

    const getClientName = (clientId?: string) => clients.find(c => c.id === clientId)?.name || 'N/A';

    return (
        <div className="space-y-4">
            <div className="flex items-center gap-2">
                 <StatCard title="Total Sales (Completed)" value={`${currency}${totalSales.toLocaleString(undefined, {minimumFractionDigits: 2})}`} />
                 <StatCard title="Avg. Order Value" value={`${currency}${averageOrderValue.toLocaleString(undefined, {minimumFractionDigits: 2})}`} />
                 <StatCard title="Open Orders" value={`${openOrders}`} />
            </div>

            <div className="flex items-center gap-2">
                <button 
                    onClick={onAddOrder}
                    className="flex-1 flex items-center justify-center gap-2 bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity"
                >
                    <PlusIcon className="w-6 h-6" />
                    Add Order
                </button>
                 <button 
                    onClick={onAddOrderByVoice}
                    className="w-12 h-12 flex-shrink-0 flex items-center justify-center bg-accent text-accent-fg font-bold rounded-xl hover:opacity-90 transition-opacity"
                    aria-label="Add Order with Voice"
                >
                    <MicrophoneIcon />
                </button>
            </div>
            
            {orders.length === 0 ? (
                 <div className="text-center text-light-fg-subtle dark:text-dark-fg-subtle mt-10 flex flex-col items-center">
                    <ClipboardListIcon className="w-12 h-12 mb-4 text-light-fg-subtle/50 dark:text-dark-fg-subtle/50" />
                    <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default">No Orders Yet</h3>
                    <p className="mb-4">Get started by adding your first order.</p>
                </div>
            ) : (
                <ul className="space-y-3">
                    {orders.map(o => (
                        <OrderItem 
                            key={o.id} 
                            order={o} 
                            currency={currency} 
                            clientName={getClientName(o.clientId)} 
                            onClick={() => onEditOrder(o)}
                        />
                    ))}
                </ul>
            )}
        </div>
    );
};

export default OrdersView;
