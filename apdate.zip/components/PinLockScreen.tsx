
import React, { useState, useEffect } from 'react';
import { AppSettings } from '../types';
import { LogoIcon } from './icons/LogoIcon';
import { useAppContext } from '../context/AppContext';

interface PinLockScreenProps {
  onUnlock: () => void;
}

const PinLockScreen: React.FC<PinLockScreenProps> = ({ onUnlock }) => {
  const { appData } = useAppContext();
  const { settings } = appData;

  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);
  const correctPin = settings.pin || '';

  useEffect(() => {
    if (pin.length === 4) {
      if (pin === correctPin) {
        onUnlock();
      } else {
        setError(true);
        setTimeout(() => {
          setError(false);
          setPin('');
        }, 1000);
      }
    }
  }, [pin, correctPin, onUnlock]);

  const handleKeyClick = (key: string) => {
    if (pin.length < 4) {
      setPin(pin + key);
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
  };
  
  const PinDot: React.FC<{ active: boolean }> = ({ active }) => (
    <div className={`w-4 h-4 rounded-full border-2 ${active ? 'bg-accent border-accent' : 'border-dark-border-default'} transition-all`}></div>
  );

  return (
    <div className="flex flex-col items-center justify-between h-screen w-screen bg-dark-bg-default p-8 text-dark-fg-default">
      <div className="flex flex-col items-center mt-16">
        <LogoIcon className="h-10 w-auto mb-6" />
        <h1 className="text-xl font-medium">Enter PIN</h1>
      </div>
      
      <div className={`flex space-x-6 mb-8 ${error ? 'animate-shake' : ''}`}>
        <PinDot active={pin.length >= 1} />
        <PinDot active={pin.length >= 2} />
        <PinDot active={pin.length >= 3} />
        <PinDot active={pin.length >= 4} />
      </div>

      <div className="grid grid-cols-3 gap-6 w-full max-w-xs">
        {[...Array(9)].map((_, i) => (
          <button key={i + 1} onClick={() => handleKeyClick(String(i + 1))} className="text-3xl font-light p-4 rounded-full bg-dark-bg-subtle hover:bg-dark-bg-inset transition-colors aspect-square flex items-center justify-center">
            {i + 1}
          </button>
        ))}
        <div /> 
        <button onClick={() => handleKeyClick('0')} className="text-3xl font-light p-4 rounded-full bg-dark-bg-subtle hover:bg-dark-bg-inset transition-colors aspect-square flex items-center justify-center">
          0
        </button>
        <button onClick={handleDelete} className="text-xl p-4 rounded-full flex items-center justify-center bg-dark-bg-subtle hover:bg-dark-bg-inset transition-colors aspect-square">
          ⌫
        </button>
      </div>

       <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
          20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default PinLockScreen;
