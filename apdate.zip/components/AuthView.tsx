import React, { useState } from 'react';
import firebase from 'firebase/compat/app';
import { auth } from '../firebase';
import { AppIcon } from './icons/AppIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

const AuthView: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAuthAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (isLogin) {
        await auth.signInWithEmailAndPassword(email, password);
      } else {
        await auth.createUserWithEmailAndPassword(email, password);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError('');
    const provider = new firebase.auth.GoogleAuthProvider();
    try {
        await auth.signInWithPopup(provider);
    } catch (err: any) {
        setError(err.message);
    } finally {
        setLoading(false);
    }
  };

  const commonInputClasses = "w-full bg-light-bg-inset dark:bg-dark-bg-inset border-2 border-transparent rounded-xl focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors focus-within:ring-2 focus-within:ring-accent focus-within:border-transparent py-3 px-4";

  return (
    <div className="fixed inset-0 bg-light-bg-default dark:bg-dark-bg-default flex items-center justify-center z-50 p-4">
      <div className="w-full max-w-sm">
        <div className="flex justify-center mb-8">
          <AppIcon className="h-20 w-auto" />
        </div>
        
        <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-8 rounded-2xl animate-fade-in space-y-4 border border-light-border-default dark:border-dark-border-default">
          <h1 className="text-2xl font-bold text-center text-light-fg-default dark:text-dark-fg-default">
            {isLogin ? 'Welcome Back!' : 'Create Account'}
          </h1>
          
          {error && <p className="text-destructive text-sm text-center bg-destructive/10 p-2 rounded-lg">{error}</p>}
          
          <form onSubmit={handleAuthAction} className="space-y-4">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Email"
              className={commonInputClasses}
              required
            />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              className={commonInputClasses}
              required
            />
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center"
            >
              {loading && <SpinnerIcon className="w-5 h-5 mr-2" />}
              {isLogin ? 'Log In' : 'Sign Up'}
            </button>
          </form>

          <div className="relative my-4">
              <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-light-border-default dark:border-dark-border-default"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-light-bg-subtle dark:bg-dark-bg-subtle text-light-fg-subtle dark:text-dark-fg-subtle">OR</span>
              </div>
          </div>
          
          <button
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full bg-white dark:bg-dark-bg-inset border border-light-border-default dark:border-dark-border-default text-light-fg-default dark:text-dark-fg-default font-bold py-3 px-4 rounded-xl hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset/80 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
          >
              <svg className="w-5 h-5" role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>Google</title><path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-5.113 2.4-4.333 0-7.4-3.4-7.4-7.8s3.067-7.8 7.4-7.8c2.4 0 3.867 1.027 4.8 2.027l2.8-2.8C18.6 1.467 15.867 0 12.48 0 5.867 0 .333 5.333.333 12s5.534 12 12.147 12c3.267 0 5.6-1.2 7.4-3.133 1.933-2.066 2.533-4.866 2.533-7.2z" fill="#4285F4"/><path d="M-1.6 15.6h17.4v3.2h-17.4z" transform="matrix(.03828 0 0 .0385 -1.025 1.084)" fill="#34A853"/><path d="M136.8 126h32.8v17.4h-32.8z" transform="matrix(.03828 0 0 .0385 -1.025 1.084)" fill="#FBBC05"/><path d="M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133l2.867 2.867c2.4-2.267 3.8-5.733 3.8-9.4z" fill="#EA4335"/></svg>
              Sign in with Google
          </button>

          <p className="text-center text-sm">
            {isLogin ? "Don't have an account?" : 'Already have an account?'}
            <button onClick={() => setIsLogin(!isLogin)} className="font-semibold text-accent hover:underline ml-1">
              {isLogin ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AuthView;