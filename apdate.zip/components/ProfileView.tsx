
import React, { useState } from 'react';
import { AppData, Client, Vendor } from '../types';
import { UsersIcon } from './icons/UsersIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import AddClientModal from './AddClientModal';
import AddVendorModal from './AddVendorModal';
import { EditIcon } from './icons/EditIcon';
import { TrashIcon } from './icons/TrashIcon';
import { PlusIcon } from './icons/PlusIcon';
import { useAppContext } from '../context/AppContext';

type ModalState = 
    | { mode: 'addClient' | 'addVendor' }
    | { mode: 'editClient', client: Client }
    | { mode: 'editVendor', vendor: Vendor }
    | null;


const ProfileView: React.FC = () => {
  const { 
    dataForActiveBusiness,
    usedClientIds,
    usedVendorIds, 
    addClient, 
    updateClient, 
    deleteClient,
    addVendor,
    updateVendor,
    deleteVendor
  } = useAppContext();

  const { clients, vendors } = dataForActiveBusiness;
  const [modalState, setModalState] = useState<ModalState>(null);

  const Section: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode, onAddClick?: () => void}> = ({ title, icon, children, onAddClick }) => (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-3 text-sm font-semibold text-light-fg-subtle dark:text-dark-fg-subtle">
          {icon}
          <h3>{title.toUpperCase()}</h3>
        </div>
        {onAddClick && (
            <button onClick={onAddClick} className="flex items-center gap-1 text-sm font-semibold text-accent hover:opacity-80 transition-opacity">
                <PlusIcon className="w-5 h-5" /> Add New
            </button>
        )}
      </div>
      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl overflow-hidden border border-light-border-default dark:border-dark-border-default">
        {children}
      </div>
    </div>
  );


  return (
    <>
      <div className="space-y-6">
        <Section title="Clients" icon={<UsersIcon />} onAddClick={() => setModalState({ mode: 'addClient' })}>
          {clients.length > 0 ? clients.map((client) => (
            <div key={client.id} className="flex items-center justify-between p-4 border-b border-light-border-default dark:border-dark-border-default last:border-b-0">
                <div className="flex-grow">
                  <span className="font-medium text-light-fg-default dark:text-dark-fg-default">{client.name}</span>
                </div>
                <div className="flex-shrink-0 ml-4 flex items-center gap-2">
                  <button onClick={() => setModalState({ mode: 'editClient', client })} className="p-2 rounded-md text-light-fg-subtle hover:text-accent hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors"><EditIcon /></button>
                  <button 
                      onClick={() => deleteClient(client.id, usedClientIds.has(client.id))}
                      title={'Delete Client'}
                      className="p-2 rounded-md text-light-fg-subtle hover:text-destructive hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors">
                      <TrashIcon />
                  </button>
                </div>
            </div>
          )) : (
              <p className="text-center text-sm p-4 text-light-fg-subtle dark:text-dark-fg-subtle">No clients added yet.</p>
          )}
        </Section>
        
        <Section title="Vendors" icon={<BriefcaseIcon />} onAddClick={() => setModalState({ mode: 'addVendor' })}>
          {vendors.length > 0 ? vendors.map((vendor) => (
            <div key={vendor.id} className="flex items-center justify-between p-4 border-b border-light-border-default dark:border-dark-border-default last:border-b-0">
                <div className="flex-grow">
                  <span className="font-medium text-light-fg-default dark:text-dark-fg-default">{vendor.name}</span>
                </div>
                <div className="flex-shrink-0 ml-4 flex items-center gap-2">
                   <button onClick={() => setModalState({ mode: 'editVendor', vendor })} className="p-2 rounded-md text-light-fg-subtle hover:text-accent hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors"><EditIcon /></button>
                   <button 
                     onClick={() => deleteVendor(vendor.id, usedVendorIds.has(vendor.id))}
                     title={'Delete Vendor'}
                     className="p-2 rounded-md text-light-fg-subtle hover:text-destructive hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors"
                   >
                       <TrashIcon />
                   </button>
                </div>
            </div>
          )) : (
              <p className="text-center text-sm p-4 text-light-fg-subtle dark:text-dark-fg-subtle">No vendors added yet.</p>
          )}
        </Section>
      </div>

      {(modalState?.mode === 'addClient' || modalState?.mode === 'editClient') && (
        <AddClientModal
          onClose={() => setModalState(null)}
          onAddClient={clientData => {
            addClient(clientData);
            setModalState(null);
          }}
          clientToEdit={modalState.mode === 'editClient' ? modalState.client : undefined}
          onUpdateClient={clientData => {
            updateClient(clientData);
            setModalState(null);
          }}
        />
      )}

      {(modalState?.mode === 'addVendor' || modalState?.mode === 'editVendor') && (
        <AddVendorModal
          onClose={() => setModalState(null)}
          onAddVendor={vendorData => {
            addVendor(vendorData);
            setModalState(null);
          }}
          vendorToEdit={modalState.mode === 'editVendor' ? modalState.vendor : undefined}
          onUpdateVendor={vendorData => {
            updateVendor(vendorData);
            setModalState(null);
          }}
        />
      )}
    </>
  );
};

export default ProfileView;
