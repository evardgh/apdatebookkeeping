
import React, { useState } from 'react';
import { Transaction, TransactionType, Client, Vendor, Business, Payment } from '../types';
import { CloseIcon } from './icons/CloseIcon';
import { UserIcon } from './icons/UserIcon';
import { BriefcaseIcon } from './icons/BriefcaseIcon';
import { EditIcon } from './icons/EditIcon';
import { TrashIcon } from './icons/TrashIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { generatePdf } from '../services/pdfService';
import StatusBadge from './StatusBadge';
import { ClipboardListIcon } from './icons/ClipboardListIcon';
import { useAppContext } from '../context/AppContext';

interface TransactionDetailModalProps {
  transaction: Transaction;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

const RecordPaymentForm: React.FC<{ transactionId: string; currency: string; onAddPayment: (transactionId: string, payment: Omit<Payment, 'id'>) => void; amountDue: number }> = ({ transactionId, currency, onAddPayment, amountDue }) => {
    const [amount, setAmount] = useState(amountDue.toFixed(2));
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [method, setMethod] = useState<'cash' | 'card' | 'bank_transfer' | 'other'>('bank_transfer');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onAddPayment(transactionId, {
            amount: parseFloat(amount),
            date: new Date(date).toISOString(),
            method,
        });
        setAmount('');
    };

    return (
        <form onSubmit={handleSubmit} className="mt-4 p-4 bg-light-bg-inset dark:bg-dark-bg-inset rounded-xl space-y-3">
            <h4 className="font-semibold text-light-fg-default dark:text-dark-fg-default">Record a Payment</h4>
            <div className="grid grid-cols-2 gap-3">
                <div>
                    <label className="text-xs font-medium text-light-fg-subtle dark:text-dark-fg-subtle">Amount</label>
                    <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full bg-light-bg-subtle dark:bg-dark-bg-subtle border-transparent rounded-lg p-2 text-sm" required step="0.01" />
                </div>
                 <div>
                    <label className="text-xs font-medium text-light-fg-subtle dark:text-dark-fg-subtle">Date</label>
                    <input type="date" value={date} onChange={e => setDate(e.target.value)} className="w-full bg-light-bg-subtle dark:bg-dark-bg-subtle border-transparent rounded-lg p-2 text-sm" required />
                </div>
            </div>
             <div>
                <label className="text-xs font-medium text-light-fg-subtle dark:text-dark-fg-subtle">Method</label>
                <select value={method} onChange={e => setMethod(e.target.value as any)} className="w-full bg-light-bg-subtle dark:bg-dark-bg-subtle border-transparent rounded-lg p-2 text-sm" required>
                    <option value="bank_transfer">Bank Transfer</option>
                    <option value="card">Card</option>
                    <option value="cash">Cash</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <button type="submit" className="w-full bg-accent text-accent-fg font-bold py-2.5 px-4 rounded-xl hover:opacity-90 transition-opacity">Record Payment</button>
        </form>
    )
}

const TransactionDetailModal: React.FC<TransactionDetailModalProps> = ({ transaction, onClose, onEdit, onDelete }) => {
  const { activeBusiness, dataForActiveBusiness, appData, addPayment } = useAppContext();
  const { clients, vendors } = dataForActiveBusiness;
  const currency = activeBusiness?.currency || '';
  
  const client = clients.find(c => c.id === transaction.clientId);
  const vendor = vendors.find(v => v.id === transaction.vendorId);
  const quote = appData.quotations.find(q => q.id === transaction.relatedQuotationId);

  const isIncome = transaction.type === TransactionType.INCOME;
  
  const totalPaid = transaction.payments.reduce((sum, p) => sum + p.amount, 0);
  const amountDue = transaction.amount - totalPaid;

  const handleDownloadInvoice = () => {
      if (!activeBusiness || !client) {
          alert("Business or Client data is missing for PDF generation.");
          return;
      }
      generatePdf({
          document: transaction,
          business: activeBusiness,
          client,
          quote: quote,
          type: 'Invoice'
      })
  }

  const OrderStatusBadge: React.FC<{status?: string}> = ({ status }) => {
    if (!status) return null;
    let colorClasses = 'bg-gray-200 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    switch (status) {
        case 'completed':
            colorClasses = 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'; break;
        case 'pending':
            colorClasses = 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300'; break;
        case 'in_progress':
        case 'shipped':
        case 'ready_for_pickup':
             colorClasses = 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300'; break;
        case 'cancelled':
             colorClasses = 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300'; break;
    }
    return <span className={`font-semibold rounded-full capitalize px-2 py-0.5 text-xs ${colorClasses}`}>{status.replace('_', ' ')}</span>
  }


  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-sm m-4 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="p-6 flex-grow overflow-y-auto">
            <button onClick={onClose} className="absolute top-4 right-4 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
            <CloseIcon />
            </button>

            <div className="text-center">
                <p className="text-sm text-accent font-semibold">{transaction.transactionNumber}</p>
                <p className={`text-4xl font-bold my-2`}>{currency} {transaction.amount.toLocaleString()}</p>
                <div className="flex justify-center my-2 gap-2">
                    <StatusBadge status={transaction.status} large />
                    {transaction.orderStatus && <OrderStatusBadge status={transaction.orderStatus} />}
                </div>
                <p className="text-lg font-medium text-light-fg-default dark:text-dark-fg-default">{transaction.name}</p>
                <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle mt-1">
                    {new Date(transaction.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })}
                    {transaction.dueDate && ` • Due ${new Date(transaction.dueDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long' })}`}
                </p>
            </div>

            {transaction.status !== 'paid' && (
                <div className="mt-4 text-center">
                    <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">Amount Due</p>
                    <p className="text-2xl font-bold text-light-expense-fg dark:text-dark-expense-fg">{currency} {amountDue.toLocaleString()}</p>
                </div>
            )}
            
            {transaction.orderStatus && (
                <div className="mt-4 pt-4 border-t border-light-border-default dark:border-dark-border-default">
                    <h3 className="text-sm font-semibold text-light-fg-subtle dark:text-dark-fg-subtle mb-2 text-center flex items-center justify-center gap-2"><ClipboardListIcon className="w-4 h-4" /> Order Details</h3>
                    <div className="grid grid-cols-2 gap-2 text-center text-sm">
                        <div className="bg-light-bg-inset dark:bg-dark-bg-inset p-2 rounded-lg">
                            <p className="font-semibold capitalize">{transaction.fulfillmentType?.replace('_', ' ')}</p>
                            <p className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Fulfillment</p>
                        </div>
                        <div className="bg-light-bg-inset dark:bg-dark-bg-inset p-2 rounded-lg">
                            <p className="font-semibold capitalize">{transaction.deliveryMethod}</p>
                            <p className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Delivery</p>
                        </div>
                    </div>
                    {transaction.trackingNumber && (
                        <div className="bg-light-bg-inset dark:bg-dark-bg-inset p-3 rounded-lg mt-2 text-center">
                            <p className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">Tracking Number</p>
                            <p className="font-semibold text-light-fg-default dark:text-dark-fg-default">{transaction.trackingNumber}</p>
                        </div>
                    )}
                    {transaction.shippingNotes && (
                        <div className="bg-light-bg-inset dark:bg-dark-bg-inset p-3 rounded-lg mt-2 text-sm">
                            <p className="font-semibold text-light-fg-default dark:text-dark-fg-default mb-1">Shipping Notes</p>
                            <p className="text-light-fg-subtle dark:text-dark-fg-subtle">{transaction.shippingNotes}</p>
                        </div>
                    )}
                </div>
            )}

            {(client || vendor) && (
                <div className="mt-4 pt-4 border-t border-light-border-default dark:border-dark-border-default">
                {client && (
                    <div className="flex items-center justify-center gap-2 text-light-fg-subtle dark:text-dark-fg-subtle">
                    <UserIcon />
                    <span className="font-medium">{client.name}</span>
                    </div>
                )}
                {vendor && (
                    <div className="flex items-center justify-center gap-2 text-light-fg-subtle dark:text-dark-fg-subtle">
                    <BriefcaseIcon />
                    <span className="font-medium">{vendor.name}</span>
                    </div>
                )}
                </div>
            )}
            
            {transaction.payments.length > 0 && (
                <div className="mt-4">
                    <h3 className="text-sm font-semibold text-light-fg-subtle dark:text-dark-fg-subtle mb-2 text-center">Payment History</h3>
                    <ul className="text-sm space-y-2">
                        {transaction.payments.map(p => (
                            <li key={p.id} className="flex justify-between items-center p-2 bg-light-bg-inset dark:bg-dark-bg-inset rounded-lg">
                                <div>
                                    <p className="font-medium">{new Date(p.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</p>
                                    <p className="text-xs capitalize text-light-fg-subtle dark:text-dark-fg-subtle">{p.method.replace('_', ' ')}</p>
                                </div>
                                <p className="font-semibold text-light-income-fg dark:text-dark-income-fg">{currency} {p.amount.toLocaleString()}</p>
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {transaction.status !== 'paid' && (
                <RecordPaymentForm transactionId={transaction.id} currency={currency} onAddPayment={addPayment} amountDue={amountDue} />
            )}

            {transaction.receiptImage && (
                <div className="mt-6">
                    <h3 className="text-sm font-semibold text-light-fg-subtle dark:text-dark-fg-subtle mb-2 text-center">Receipt</h3>
                    <img 
                        src={transaction.receiptImage} 
                        alt="Receipt" 
                        className="rounded-lg w-full h-auto object-contain max-h-60 border border-light-border-default dark:border-dark-border-default"
                    />
                </div>
            )}
        </div>
        <div className="p-4 bg-light-bg-inset dark:bg-dark-bg-inset mt-auto border-t border-light-border-default dark:border-dark-border-default">
            <div className="flex gap-3">
                <button onClick={onEdit} className="flex-1 flex items-center justify-center gap-2 bg-light-bg-subtle dark:bg-dark-bg-subtle text-light-fg-default dark:text-dark-fg-default font-bold py-3 px-4 rounded-xl hover:opacity-80 transition-opacity">
                    <EditIcon className="w-4 h-4" />
                    Edit
                </button>
                <button onClick={onDelete} className="flex-1 flex items-center justify-center gap-2 bg-light-expense-bg/20 dark:bg-dark-expense-bg/20 text-light-expense-fg dark:text-dark-expense-fg font-bold py-3 px-4 rounded-xl hover:opacity-80 transition-opacity">
                    <TrashIcon className="w-4 h-4" />
                    Void
                </button>
            </div>
            {isIncome && activeBusiness && client && (
                <button onClick={handleDownloadInvoice} className="w-full mt-3 flex items-center justify-center gap-2 bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity">
                    <DownloadIcon className="w-5 h-5"/>
                    Download Invoice
                </button>
            )}
        </div>
      </div>
    </div>
  );
};

export default TransactionDetailModal;
