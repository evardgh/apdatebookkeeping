import React, { useState, useEffect, useRef } from 'react';
import { Business } from '../types';
import { parseBusinessFromText, enhanceText } from '../services/geminiService';
import { CloseIcon } from './icons/CloseIcon';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';
import { SparklesIcon } from './icons/SparklesIcon';

interface BusinessVoiceInputModalProps {
  onClose: () => void;
  onParseComplete: (data: Partial<Business>) => void;
}

const BusinessVoiceInputModal: React.FC<BusinessVoiceInputModalProps> = ({ onClose, onParseComplete }) => {
    const [isListening, setIsListening] = useState(false);
    const [editText, setEditText] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);
    const [isEnhancing, setIsEnhancing] = useState(false);
    const [error, setError] = useState('');
    const recognitionRef = useRef<SpeechRecognition | null>(null);

    useEffect(() => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            setError("Sorry, your browser doesn't support voice recognition.");
            return;
        }

        recognitionRef.current = new SpeechRecognition();
        const rec = recognitionRef.current;
        rec.continuous = true;
        rec.interimResults = true;
        rec.lang = 'en-US';

        rec.onresult = (event: SpeechRecognitionEvent) => {
            const transcript = Array.from(event.results)
                .map(result => result[0])
                .map(result => result.transcript)
                .join('');
            setEditText(transcript);
        };
        
        rec.onend = () => {
            setIsListening(false);
        };

        rec.onerror = (event: SpeechRecognitionErrorEvent) => {
            console.error('Speech recognition error:', event.error);
            setError(`Error: ${event.error}. Please check microphone permissions and connection.`);
            setIsListening(false);
        };
        
        return () => {
            rec?.stop();
            rec.onresult = null;
            rec.onerror = null;
            rec.onend = null;
        };
    }, []);

    const toggleListening = () => {
        if (!recognitionRef.current) return;
        if (isListening) {
            recognitionRef.current.stop();
            setIsListening(false);
        } else {
            setEditText('');
            setError('');
            recognitionRef.current.start();
            setIsListening(true);
        }
    };

    const handleEnhance = async () => {
        if (!editText.trim() || isEnhancing || isProcessing) return;
        setIsEnhancing(true);
        setError('');
        try {
            const enhancedText = await enhanceText(editText);
            setEditText(enhancedText);
        } catch(e) {
            setError("Could not enhance text. Please try again.");
        } finally {
            setIsEnhancing(false);
        }
    };
    
    const handleProcessing = async () => {
        if (!editText.trim()) {
            setError('Please enter details to process.');
            return;
        }

        setIsProcessing(true);
        setError('');
        try {
            const parsedData = await parseBusinessFromText(editText);
            if (parsedData) {
                onParseComplete(parsedData);
            } else {
                setError("Sorry, I couldn't understand that. Please try rephrasing or enter manually.");
            }
        } catch (e) {
            console.error(e);
            setError("An error occurred while parsing your request.");
        } finally {
            setIsProcessing(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
            <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-sm m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
                    <CloseIcon />
                </button>
                
                <h2 className="text-xl font-bold mb-4 text-center text-light-fg-default dark:text-dark-fg-default capitalize">Add Business with Voice</h2>
                
                <div className="flex-grow flex flex-col space-y-4">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={toggleListening}
                            className={`w-16 h-16 rounded-full flex items-center justify-center transition-colors duration-300 flex-shrink-0 relative
                                ${isListening ? 'bg-destructive text-white' : 'bg-accent text-accent-fg'}
                            `}
                        >
                            <MicrophoneIcon className="w-8 h-8" />
                            {isListening && <div className="absolute inset-0 rounded-full bg-white/30 animate-ping"></div>}
                        </button>
                        <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">
                            Tap the mic and describe your business.
                            e.g., "My business is 'Innovate Corp', email is contact@innovate.com..."
                        </p>
                    </div>

                    <textarea
                        value={editText}
                        onChange={(e) => setEditText(e.target.value)}
                        placeholder={isListening ? 'Listening...' : "Your transcribed text will appear here..."}
                        className="w-full flex-grow bg-light-bg-inset dark:bg-dark-bg-inset border-transparent focus:border-accent border-2 rounded-xl py-3 px-4 focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors resize-none min-h-[120px]"
                        rows={5}
                    />
                    
                    {error && <p className="text-destructive text-sm text-center">{error}</p>}
                </div>
                
                <div className="mt-4 space-y-2">
                    <button
                        onClick={handleEnhance}
                        disabled={isEnhancing || !editText.trim() || isProcessing}
                        className="w-full flex items-center justify-center gap-2 bg-light-bg-inset dark:bg-dark-bg-inset text-accent font-bold py-3 px-4 rounded-xl hover:bg-light-bg-inset/80 dark:hover:bg-dark-bg-inset/80 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isEnhancing ? <SpinnerIcon className="w-5 h-5 text-accent" /> : <SparklesIcon className="w-5 h-5" />}
                        Enhance with AI
                    </button>
                    <button
                        onClick={handleProcessing}
                        disabled={isProcessing || !editText.trim()}
                        className="w-full flex items-center justify-center gap-2 bg-accent text-accent-fg font-bold py-3.5 px-4 rounded-xl hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isProcessing ? <SpinnerIcon className="w-5 h-5" /> : null}
                        Process Business Info
                    </button>
                </div>
            </div>
        </div>
    );
};

export default BusinessVoiceInputModal;