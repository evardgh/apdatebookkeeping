
import React, { useState, useRef, useEffect } from 'react';
import { generateFinancialInsightStream } from '../services/geminiService';
import { Transaction, Client, Vendor } from '../types';
import { SendIcon } from './icons/SendIcon';
import { LogoIcon } from './icons/LogoIcon';
import { useAppContext } from '../context/AppContext';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

const AIAssistantView: React.FC = () => {
  const { activeBusiness, dataForActiveBusiness } = useAppContext();
  const { visibleTransactions, clients, vendors } = dataForActiveBusiness;
  const currency = activeBusiness?.currency || '';

  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const suggestions = [
    "Summarize my finances for last month.",
    "What was my biggest expense?",
    "How much did I earn from Innovate Corp?",
    "Give me one tip to improve my finances.",
  ];

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [history]);

  const handleSend = async (message?: string) => {
    const currentPrompt = message || prompt;
    if (!currentPrompt.trim() || isLoading) return;

    setIsLoading(true);
    const userMessage: ChatMessage = { role: 'user', text: currentPrompt };
    setHistory(prev => [...prev, userMessage]);
    setPrompt('');

    try {
        const stream = await generateFinancialInsightStream(currentPrompt, visibleTransactions, currency, clients, vendors);
        
        let modelResponse = '';
        setHistory(prev => [...prev, { role: 'model', text: '' }]);
        
        for await (const chunk of stream) {
            const chunkText = chunk.text;
            modelResponse += chunkText;
            setHistory(prev => {
                const newHistory = [...prev];
                newHistory[newHistory.length - 1].text = modelResponse;
                return newHistory;
            });
        }
    } catch (error) {
        console.error(error);
        const errorMessage: ChatMessage = { role: 'model', text: "Sorry, I'm having trouble connecting. Please try again later." };
        setHistory(prev => [...prev, errorMessage]);
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)]">
      <div className="flex-grow overflow-y-auto space-y-4 pr-2">
        {history.length === 0 && (
          <div className="text-center p-4">
            <h2 className="text-xl font-semibold text-light-fg-default dark:text-dark-fg-default">Apdate AI</h2>
            <p className="text-light-fg-subtle dark:text-dark-fg-subtle">Ask me anything about your finances.</p>
            <div className="grid grid-cols-2 gap-3 mt-6">
                {suggestions.map((s, i) => (
                    <button key={i} onClick={() => handleSend(s)} className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-3 rounded-xl text-sm text-left hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors text-light-fg-default dark:text-dark-fg-default">
                        {s}
                    </button>
                ))}
            </div>
          </div>
        )}
        {history.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl ${
                msg.role === 'user'
                  ? 'bg-accent text-accent-fg rounded-br-lg'
                  : 'bg-light-bg-subtle dark:bg-dark-bg-subtle text-light-fg-default dark:text-dark-fg-default rounded-bl-lg'
              }`}
              style={{ whiteSpace: 'pre-wrap' }}
            >
              {msg.text}
              {msg.role === 'model' && isLoading && index === history.length - 1 && (
                  <span className="inline-block w-2 h-2 ml-2 bg-light-fg-subtle dark:bg-dark-fg-subtle rounded-full animate-pulse"></span>
              )}
            </div>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      <div className="mt-4 flex items-center gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask a question..."
          disabled={isLoading}
          className="flex-grow bg-light-bg-subtle dark:bg-dark-bg-subtle border-none rounded-full py-3.5 px-5 focus:outline-none focus:ring-2 focus:ring-accent transition text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle"
        />
        <button
          onClick={() => handleSend()}
          disabled={isLoading || !prompt.trim()}
          className="flex-shrink-0 w-12 h-12 bg-accent rounded-full text-accent-fg flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
        >
          <SendIcon />
        </button>
      </div>
    </div>
  );
};

export default AIAssistantView;
