
import React from 'react';
import { Transaction, Quotation, Business, Client, Payment } from '../types';
import { generatePdf } from '../services/pdfService';
import { CloseIcon } from './icons/CloseIcon';
import { DownloadIcon } from './icons/DownloadIcon';
import { EditIcon } from './icons/EditIcon';
import { TrashIcon } from './icons/TrashIcon';
import { ConvertIcon } from './icons/ConvertIcon';
import StatusBadge from './StatusBadge';
import { useAppContext } from '../context/AppContext';

interface PreviewModalProps {
  document: Transaction | Quotation;
  mode: 'invoice' | 'quotation';
  onClose: () => void;
  onEdit?: (quote: Quotation) => void;
  onDelete?: (id: string) => void;
  onConvert?: (quote: Quotation) => void;
  addPayment?: (transactionId: string, payment: Omit<Payment, 'id'>) => void;
  business: Business;
  client?: Client;
  quote?: Quotation;
}

const PreviewModal: React.FC<PreviewModalProps> = ({ document, mode, onClose, onEdit, onDelete, onConvert, addPayment, business, client, quote }) => {
  
  const isQuote = mode === 'quotation';
  const doc = document as Quotation;
  const inv = document as Transaction;
  
  const docNumber = isQuote ? doc.quotationNumber : inv.transactionNumber;
  const docDate = new Date(document.date).toLocaleDateString();
  const total = isQuote ? doc.total : inv.amount;

  const items = isQuote ? doc.items : quote?.items || [{
    id: inv.id, name: inv.name, quantity: inv.quantity || 1, unitPrice: inv.unitPrice || inv.amount, description: inv.description
  }];

  const handleDownload = () => {
    generatePdf({
      document,
      business,
      client,
      quote: quote,
      type: isQuote ? 'Quotation' : 'Invoice'
    });
  };

  const status = isQuote ? doc.status : inv.status;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-lg m-4 max-h-[90vh] flex flex-col animate-slide-up border border-light-border-default/50 dark:border-dark-border-default" onClick={(e) => e.stopPropagation()}>
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-light-border-default dark:border-dark-border-default">
          <div>
            <h2 className="text-xl font-bold text-light-fg-default dark:text-dark-fg-default capitalize">{mode}</h2>
            <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">{docNumber}</p>
          </div>
          <button onClick={onClose} className="text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
            <CloseIcon />
          </button>
        </div>
        
        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-6">
            <div className="grid grid-cols-2 gap-6 text-sm">
                <div>
                    <h3 className="font-semibold text-light-fg-subtle dark:text-dark-fg-subtle">From</h3>
                    <p className="font-bold text-light-fg-default dark:text-dark-fg-default">{business.name}</p>
                </div>
                <div>
                    <h3 className="font-semibold text-light-fg-subtle dark:text-dark-fg-subtle">To</h3>
                    <p className="font-bold text-light-fg-default dark:text-dark-fg-default">{client?.name || 'N/A'}</p>
                    <p>{client?.email}</p>
                </div>
            </div>

            <div className="grid grid-cols-3 gap-6 text-sm">
                <p><span className="font-semibold block text-light-fg-subtle dark:text-dark-fg-subtle">Status</span> <StatusBadge status={status} /></p>
                <p><span className="font-semibold block text-light-fg-subtle dark:text-dark-fg-subtle">Issued Date</span> {docDate}</p>
                {isQuote && <p><span className="font-semibold block text-light-fg-subtle dark:text-dark-fg-subtle">Expiry Date</span> {new Date(doc.expiryDate).toLocaleDateString()}</p>}
                {!isQuote && inv.dueDate && <p><span className="font-semibold block text-light-fg-subtle dark:text-dark-fg-subtle">Due Date</span> {new Date(inv.dueDate).toLocaleDateString()}</p>}
            </div>

            {/* Items Table */}
            <div>
                 <table className="w-full text-sm">
                    <thead className="border-b-2 border-light-border-default dark:border-dark-border-default">
                        <tr className="text-left text-light-fg-subtle dark:text-dark-fg-subtle">
                            <th className="py-2 font-semibold">Item</th>
                            <th className="py-2 font-semibold text-center">Qty</th>
                            <th className="py-2 font-semibold text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        {items.map((item, index) => (
                            <tr key={index} className="border-b border-light-border-default dark:border-dark-border-default">
                                <td className="py-3 font-medium text-light-fg-default dark:text-dark-fg-default">{item.name}</td>
                                <td className="py-3 text-center">{item.quantity}</td>
                                <td className="py-3 text-right">{business.currency} {(item.quantity * item.unitPrice).toLocaleString()}</td>
                            </tr>
                        ))}
                    </tbody>
                 </table>
            </div>

            <div className="flex justify-end text-sm">
                <div className="w-full max-w-xs space-y-2">
                    <div className="flex justify-between"><span>Subtotal</span><span>{business.currency} {(isQuote ? doc.subtotal : total).toLocaleString()}</span></div>
                     <div className="flex justify-between"><span>Tax ({(isQuote ? doc.taxRate : business.taxRate)}%)</span><span>{business.currency} {(isQuote ? (doc.total - doc.subtotal) : 0).toLocaleString()}</span></div>
                    <div className="flex justify-between font-bold text-lg border-t pt-2 border-light-border-default dark:border-dark-border-default"><span>Total</span><span>{business.currency} {total.toLocaleString()}</span></div>
                </div>
            </div>
            {doc.notes && <div className="text-xs p-3 bg-light-bg-inset dark:bg-dark-bg-inset rounded-lg"><p className="font-semibold mb-1">Notes</p>{doc.notes}</div>}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-light-bg-inset dark:bg-dark-bg-inset border-t border-light-border-default dark:border-dark-border-default flex gap-2">
            <button onClick={handleDownload} className="flex-1 flex items-center justify-center gap-2 bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity">
                <DownloadIcon /> Download PDF
            </button>
            {isQuote && doc.status === 'draft' &&
                <>
                    <button onClick={() => onEdit?.(doc)} className="p-3 bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-xl"><EditIcon/></button>
                    <button onClick={() => onDelete?.(doc.id)} className="p-3 bg-light-bg-subtle dark:bg-dark-bg-subtle text-destructive rounded-xl"><TrashIcon/></button>
                </>
            }
        </div>
        {isQuote && doc.status === 'draft' && onConvert &&
            <div className="p-4 pt-0 bg-light-bg-inset dark:bg-dark-bg-inset">
                 <button onClick={() => onConvert(doc)} className="w-full flex items-center justify-center gap-2 bg-green-600 text-white font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity">
                    <ConvertIcon /> Convert to Invoice
                </button>
            </div>
        }
      </div>
    </div>
  );
};

export default PreviewModal;
