import React from 'react';
import { AppIcon } from './icons/AppIcon';

const SplashScreen: React.FC = () => {
  return (
    <div className="flex items-center justify-center h-screen w-screen bg-light-bg-default dark:bg-dark-bg-default animate-splash-fade">
      <div className="animate-pulse">
        <AppIcon className="h-24 w-auto" />
      </div>
      <style>{`
        @keyframes splash-fade {
          0% { opacity: 0; }
          10% { opacity: 1; }
          85% { opacity: 1; }
          100% { opacity: 0; }
        }
        .animate-splash-fade {
          animation: splash-fade 1.5s forwards;
        }
      `}</style>
    </div>
  );
};

export default SplashScreen;