import React from 'react';
import { CloseIcon } from './icons/CloseIcon';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import { EditIcon } from './icons/EditIcon';

interface AddOptionsOverlayProps {
  onClose: () => void;
  onManualClick: () => void;
  onVoiceClick: () => void;
}

const AddOptionsOverlay: React.FC<AddOptionsOverlayProps> = ({ onClose, onManualClick, onVoiceClick }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex flex-col items-center justify-end z-40 animate-fade-in" onClick={onClose}>
        <div className="w-full max-w-md p-4 animate-slide-up-fast">
            <div className="grid grid-cols-2 gap-4">
                <OptionButton
                    label="Manual Entry"
                    icon={<EditIcon className="w-8 h-8"/>}
                    onClick={onManualClick}
                />
                 <OptionButton
                    label="Voice Entry"
                    icon={<MicrophoneIcon className="w-8 h-8"/>}
                    onClick={onVoiceClick}
                />
            </div>
             <button
                onClick={onClose}
                className="w-16 h-16 mt-6 mx-auto bg-white/20 rounded-full flex items-center justify-center text-white"
                aria-label="Close"
            >
                <CloseIcon />
            </button>
        </div>
    </div>
  );
};

const OptionButton: React.FC<{label: string, icon: React.ReactNode, onClick: () => void}> = ({ label, icon, onClick }) => (
    <button onClick={onClick} className="flex flex-col items-center justify-center gap-2 bg-white/10 backdrop-blur-md rounded-2xl p-6 text-white h-32 hover:bg-white/20 transition-colors">
        {icon}
        <span className="font-semibold">{label}</span>
    </button>
)

export default AddOptionsOverlay;
