
import React, { useState, useMemo } from 'react';
import { Transaction, TransactionType, Client, Vendor, Business, Quotation, Payment } from '../types';
import { PaperclipIcon } from './icons/PaperclipIcon';
import TransactionDetailModal from './TransactionDetailModal';
import { PlusIcon } from './icons/PlusIcon';
import StatusBadge from './StatusBadge';
import { useAppContext } from '../context/AppContext';

interface TransactionsViewProps {
  onEditTransaction: (transaction: Transaction) => void;
  onAddTransactionClick: () => void;
}

const TransactionItem: React.FC<{ transaction: Transaction; currency: string; onClick: () => void }> = ({ transaction, currency, onClick }) => {
    const isIncome = transaction.type === TransactionType.INCOME;
    const amountColor = isIncome ? 'text-light-income-fg dark:text-dark-income-fg' : 'text-light-expense-fg dark:text-dark-expense-fg';
    
    return (
        <li onClick={onClick} className="p-4 bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl cursor-pointer hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors">
            <div className="flex items-start justify-between">
                <div className="truncate pr-4">
                    <p className="font-semibold text-light-fg-default dark:text-dark-fg-default truncate">{transaction.name}</p>
                    <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">
                        {new Date(transaction.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        {' • '}
                        {transaction.category}
                    </p>
                    <p className="text-xs text-light-fg-subtle dark:text-dark-fg-subtle">{transaction.transactionNumber}</p>
                </div>
                <div className="flex flex-col items-end flex-shrink-0 ml-2">
                    <p className={`font-semibold ${amountColor}`}>
                        {isIncome ? '+' : '-'} {currency} {transaction.amount.toLocaleString()}
                    </p>
                    <div className="mt-1 flex items-center gap-2">
                        {transaction.receiptImage && <PaperclipIcon className="w-4 h-4 text-light-fg-subtle dark:text-dark-fg-subtle" />}
                        <StatusBadge status={transaction.status} />
                    </div>
                </div>
            </div>
        </li>
    );
};

const TransactionsView: React.FC<TransactionsViewProps> = ({ onEditTransaction, onAddTransactionClick }) => {
    const { activeBusiness, dataForActiveBusiness, deleteTransaction } = useAppContext();
    const { visibleTransactions, clients, vendors } = dataForActiveBusiness;
    const currency = activeBusiness?.currency || '';

    const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const filteredTransactions = useMemo(() => {
        if (!searchTerm) {
            return visibleTransactions;
        }
        const lowercasedTerm = searchTerm.toLowerCase();
        return visibleTransactions.filter(t => {
            const clientName = t.clientId ? clients.find(c => c.id === t.clientId)?.name.toLowerCase() : '';
            const vendorName = t.vendorId ? vendors.find(v => v.id === t.vendorId)?.name.toLowerCase() : '';

            return (
                t.name.toLowerCase().includes(lowercasedTerm) ||
                t.category.toLowerCase().includes(lowercasedTerm) ||
                t.amount.toString().includes(lowercasedTerm) ||
                t.status.toLowerCase().includes(lowercasedTerm) ||
                (clientName && clientName.includes(lowercasedTerm)) ||
                (vendorName && vendorName.includes(lowercasedTerm))
            );
        });
    }, [visibleTransactions, searchTerm, clients, vendors]);

    const handleEdit = () => {
        if (selectedTransaction) {
            onEditTransaction(selectedTransaction);
            setSelectedTransaction(null);
        }
    };

    const handleDelete = () => {
        if (selectedTransaction) {
            deleteTransaction(selectedTransaction.id);
            setSelectedTransaction(null);
        }
    };
    
    if (visibleTransactions.length === 0 && !searchTerm) {
        return (
            <div className="text-center text-light-fg-subtle dark:text-dark-fg-subtle mt-10 flex flex-col items-center">
                <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default">No Transactions Yet</h3>
                <p className="mb-4">Get started by adding your first transaction.</p>
                <button 
                    onClick={onAddTransactionClick}
                    className="flex items-center gap-2 bg-accent text-accent-fg font-bold py-3 px-5 rounded-full hover:opacity-90 transition-opacity"
                >
                    <PlusIcon className="w-6 h-6" />
                    Add Transaction
                </button>
            </div>
        );
    }
    
    return (
        <>
            <div className="mb-4">
                <input
                    type="search"
                    placeholder="Search by name, category, amount, status..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-light-bg-inset dark:bg-dark-bg-inset border-none rounded-xl py-3 px-4 focus:outline-none focus:ring-2 focus:ring-accent text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle"
                />
            </div>
            {filteredTransactions.length > 0 ? (
                <ul className="space-y-3">
                    {filteredTransactions.map(t => (
                        <TransactionItem key={t.id} transaction={t} currency={currency} onClick={() => setSelectedTransaction(t)} />
                    ))}
                </ul>
            ) : (
                <p className="text-center text-light-fg-subtle dark:text-dark-fg-subtle mt-10">No transactions match your search.</p>
            )}

            {selectedTransaction && (
                <TransactionDetailModal
                    transaction={selectedTransaction}
                    onClose={() => setSelectedTransaction(null)}
                    onEdit={handleEdit}
                    onDelete={handleDelete}
                />
            )}
        </>
    );
};

export default TransactionsView;
