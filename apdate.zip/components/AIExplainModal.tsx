import React, { useState, useEffect } from 'react';
import { getTermExplanation } from '../services/geminiService';
import { CloseIcon } from './icons/CloseIcon';
import { SpinnerIcon } from './icons/SpinnerIcon';

interface AIExplainModalProps {
  term: string;
  onClose: () => void;
}

const AIExplainModal: React.FC<AIExplainModalProps> = ({ term, onClose }) => {
  const [explanation, setExplanation] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchExplanation = async () => {
      setIsLoading(true);
      const result = await getTermExplanation(term);
      setExplanation(result);
      setIsLoading(false);
    };

    fetchExplanation();
  }, [term]);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-sm m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default" onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} className="absolute top-4 right-4 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
          <CloseIcon />
        </button>

        <h2 className="text-xl font-bold mb-4 text-light-fg-default dark:text-dark-fg-default">What is "{term}"?</h2>

        <div className="min-h-[150px] text-light-fg-default dark:text-dark-fg-default">
          {isLoading ? (
            <div className="flex items-center justify-center h-full py-10">
              <SpinnerIcon className="w-8 h-8 text-accent" />
            </div>
          ) : (
            <p className="whitespace-pre-wrap font-sans">{explanation}</p>
          )}
        </div>
        
        <button onClick={onClose} className="w-full mt-6 bg-accent text-accent-fg font-bold py-3.5 px-4 rounded-xl hover:opacity-90 transition-opacity">
            Got it!
        </button>
      </div>
    </div>
  );
};

export default AIExplainModal;