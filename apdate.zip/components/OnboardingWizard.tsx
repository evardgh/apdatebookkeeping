import React, { useState } from 'react';
import { AppIcon } from './icons/AppIcon';

interface OnboardingWizardProps {
  onComplete: (businessName: string, currency: string, openingBalance: number) => void;
}

const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [businessName, setBusinessName] = useState('');
  const [currency, setCurrency] = useState('GH₵');
  const [openingBalance, setOpeningBalance] = useState('');

  const baseInputClasses = "w-full bg-light-bg-inset dark:bg-dark-bg-inset border-2 border-transparent rounded-xl focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors";
  const focusClasses = "focus-within:ring-2 focus-within:ring-accent focus-within:border-transparent";

  const commonSelectClasses = `${baseInputClasses} ${focusClasses} py-3 px-4`;
  const commonTextareaClasses = `${baseInputClasses} ${focusClasses} py-3 px-4`;
  const currencyInputWrapperClasses = `${baseInputClasses} ${focusClasses} flex items-center`;
  const currencyInputClasses = "w-full bg-transparent p-0 pl-2 pr-4 py-3 focus:outline-none focus:ring-0 border-none";

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (businessName.trim()) {
      setStep(2);
    }
  };

  const handleComplete = () => {
    onComplete(businessName.trim(), currency, parseFloat(openingBalance) || 0);
  };

  return (
    <div className="fixed inset-0 bg-light-bg-default dark:bg-dark-bg-default flex items-center justify-center z-50 p-4">
      <div className="w-full max-w-sm">
        <div className="flex justify-center mb-8">
          <AppIcon className="h-20 w-auto" />
        </div>
        
        {step === 1 && (
          <form onSubmit={handleStep1Submit} className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-6 rounded-2xl animate-fade-in space-y-4 border border-light-border-default dark:border-dark-border-default">
            <h1 className="text-xl font-bold text-center text-light-fg-default dark:text-dark-fg-default">Welcome to Apdate!</h1>
            <p className="text-center text-light-fg-subtle dark:text-dark-fg-subtle">Let's get your business set up.</p>
            
            <div>
              <label htmlFor="business-name" className="block text-sm font-medium mb-1.5 text-light-fg-subtle dark:text-dark-fg-subtle">Business Name</label>
              <input
                id="business-name"
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g., My Freelance Gig"
                className={commonTextareaClasses}
                required
              />
            </div>
            
            <div>
              <label htmlFor="currency" className="block text-sm font-medium mb-1.5 text-light-fg-subtle dark:text-dark-fg-subtle">Currency</label>
              <select
                id="currency"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className={commonSelectClasses}
              >
                <option value="GH₵">GH₵ - Ghanaian Cedi</option>
                <option value="$">USD - US Dollar</option>
                <option value="€">EUR - Euro</option>
                <option value="£">GBP - British Pound</option>
              </select>
            </div>
            
            <button type="submit" className="w-full bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity">
              Continue
            </button>
          </form>
        )}
        
        {step === 2 && (
          <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-6 rounded-2xl animate-fade-in space-y-4 border border-light-border-default dark:border-dark-border-default">
            <h1 className="text-xl font-bold text-center text-light-fg-default dark:text-dark-fg-default">Set Your Starting Balance</h1>
             <p className="text-center text-sm text-light-fg-subtle dark:text-dark-fg-subtle">
               This is the amount of cash your business has right now. It will be recorded as "Owner's Equity". You can skip this and add it later.
            </p>
            
            <div>
              <label htmlFor="opening-balance" className="block text-sm font-medium mb-1.5 text-light-fg-subtle dark:text-dark-fg-subtle">Opening Balance (Optional)</label>
              <div className={currencyInputWrapperClasses}>
                <span className="pl-4 pr-2 text-light-fg-subtle dark:text-dark-fg-subtle">{currency}</span>
                <input
                  id="opening-balance"
                  type="number"
                  value={openingBalance}
                  onChange={(e) => setOpeningBalance(e.target.value)}
                  placeholder="0.00"
                  className={currencyInputClasses}
                  step="0.01"
                />
              </div>
            </div>
            
            <button onClick={handleComplete} className="w-full bg-accent text-accent-fg font-bold py-3 px-4 rounded-xl hover:opacity-90 transition-opacity">
              Finish Setup
            </button>
             <button onClick={() => setStep(1)} className="w-full text-center text-sm text-light-fg-subtle dark:text-dark-fg-subtle hover:underline mt-2">
              Back
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default OnboardingWizard;