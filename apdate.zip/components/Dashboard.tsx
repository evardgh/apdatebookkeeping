
import React, { useMemo, useState, useRef, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Transaction, TransactionType, Business, View } from '../types';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { XCircleIcon } from './icons/XCircleIcon';
import { BusinessIcon } from './icons/BusinessIcon';
import StatusBadge from './StatusBadge';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { SettingsIcon } from './icons/SettingsIcon';
import { useAppContext } from '../context/AppContext';

interface DashboardProps {
  setCurrentView: (view: View) => void;
}

const StatCard: React.FC<{ title: string; amount: number; currency: string; className?: string }> = ({ title, amount, currency, className }) => (
  <div className={`bg-light-bg-subtle dark:bg-dark-bg-subtle p-4 rounded-2xl ${className}`}>
    <h3 className="text-sm font-medium text-light-fg-subtle dark:text-dark-fg-subtle">{title}</h3>
    <p className="text-2xl font-semibold text-light-fg-default dark:text-dark-fg-default">{currency} {amount.toLocaleString()}</p>
  </div>
);

const OutstandingItem: React.FC<{ transaction: Transaction; currency: string }> = ({ transaction, currency }) => {
    const amountDue = transaction.amount - transaction.payments.reduce((sum, p) => sum + p.amount, 0);
    const isOverdue = transaction.dueDate && new Date(transaction.dueDate) < new Date();

    return (
        <li className="flex items-center justify-between py-3">
            <div className="truncate">
                <p className="font-medium text-light-fg-default dark:text-dark-fg-default truncate">{transaction.name}</p>
                <p className={`text-sm ${isOverdue ? 'text-destructive' : 'text-light-fg-subtle dark:text-dark-fg-subtle'}`}>
                    {isOverdue ? 'Overdue' : 'Due'}: {transaction.dueDate ? new Date(transaction.dueDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : 'N/A'}
                </p>
            </div>
            <p className="font-semibold text-light-fg-default dark:text-dark-fg-default">
                {currency} {amountDue.toLocaleString()}
            </p>
        </li>
    );
};

const BusinessSwitcher: React.FC<{
    activeBusiness: Business;
    allBusinesses: Business[];
    setActiveBusinessId: (id: string) => void;
    setCurrentView: (view: View) => void;
}> = ({ activeBusiness, allBusinesses, setActiveBusinessId, setCurrentView }) => {
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [wrapperRef]);
    
    const handleSelect = (id: string) => {
        setActiveBusinessId(id);
        setIsOpen(false);
    }

    return (
        <div className="relative" ref={wrapperRef}>
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex items-center gap-4 bg-light-bg-subtle dark:bg-dark-bg-subtle p-4 rounded-2xl text-left hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors">
                {activeBusiness.logo ? (
                    <img src={activeBusiness.logo} alt="Business Logo" className="h-14 w-14 rounded-full object-cover flex-shrink-0" />
                ) : (
                    <div className="h-14 w-14 rounded-full bg-light-bg-inset dark:bg-dark-bg-inset flex items-center justify-center text-light-fg-subtle dark:text-dark-fg-subtle flex-shrink-0">
                        <BusinessIcon /> 
                    </div>
                )}
                <div className="flex-grow">
                    <p className="text-sm text-light-fg-subtle dark:text-dark-fg-subtle">Active Business</p>
                    <h2 className="text-xl font-bold text-light-fg-default dark:text-dark-fg-default truncate">{activeBusiness.name}</h2>
                </div>
                <ChevronDownIcon className={`w-6 h-6 text-light-fg-subtle dark:text-dark-fg-subtle transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
                <div className="absolute top-full mt-2 w-full bg-light-bg-default dark:bg-dark-bg-subtle rounded-2xl shadow-lg border border-light-border-default dark:border-dark-border-default z-10 overflow-hidden animate-fade-in-fast">
                    <ul>
                        {allBusinesses.map(b => (
                            <li key={b.id}>
                                <button onClick={() => handleSelect(b.id)} className="w-full text-left px-4 py-3 hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors flex items-center gap-3">
                                    {b.id === activeBusiness.id && <CheckCircleIcon className="w-5 h-5 text-accent" />}
                                    <span className={`font-semibold ${b.id === activeBusiness.id ? 'text-accent' : 'ml-8 text-light-fg-default dark:text-dark-fg-default'}`}>{b.name}</span>
                                </button>
                            </li>
                        ))}
                    </ul>
                    <div className="border-t border-light-border-default dark:border-dark-border-default">
                        <button onClick={() => { setCurrentView('businesses'); setIsOpen(false); }} className="w-full text-left px-4 py-3 hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors flex items-center gap-3 text-light-fg-default dark:text-dark-fg-default">
                           <SettingsIcon className="w-5 h-5 ml-1.5 text-light-fg-subtle dark:text-dark-fg-subtle"/>
                           <span className="font-semibold">Manage Businesses</span>
                        </button>
                    </div>
                </div>
            )}
        </div>
    )
}


const Dashboard: React.FC<DashboardProps> = ({ setCurrentView }) => {
  const { appData, activeBusiness, dataForActiveBusiness, setActiveBusinessId } = useAppContext();
  const { visibleTransactions } = dataForActiveBusiness;
  const currency = activeBusiness?.currency || '';

  const { totalIncome, totalExpense, netProfit, outstandingInvoices, billsToPay } = useMemo(() => {
    let income = 0;
    let expense = 0;
    const outstanding: Transaction[] = [];
    const bills: Transaction[] = [];

    visibleTransactions.forEach(t => {
      if (t.type === TransactionType.INCOME) {
        income += t.amount;
        if (t.status === 'unpaid' || t.status === 'partially_paid') {
            outstanding.push(t);
        }
      } else {
        expense += t.amount;
        if (t.status === 'unpaid' || t.status === 'partially_paid') {
            bills.push(t);
        }
      }
    });
    return { 
        totalIncome: income, 
        totalExpense: expense, 
        netProfit: income - expense,
        outstandingInvoices: outstanding,
        billsToPay: bills,
    };
  }, [visibleTransactions]);

  const chartData = useMemo(() => {
    const monthlyData: { [key: string]: { name: string; income: number; expense: number } } = {};
    visibleTransactions.forEach(t => {
      const month = new Date(t.date).toLocaleString('default', { month: 'short', year: '2-digit' });
      if (!monthlyData[month]) {
        monthlyData[month] = { name: month, income: 0, expense: 0 };
      }
      if (t.type === TransactionType.INCOME) {
        monthlyData[month].income += t.amount;
      } else {
        monthlyData[month].expense += t.amount;
      }
    });
    return Object.values(monthlyData).reverse();
  }, [visibleTransactions]);
  
  const isDark = document.documentElement.classList.contains('dark');
  const incomeColor = isDark ? '#34D399' : '#057A55';
  const expenseColor = isDark ? '#F98080' : '#D92D20';

  if (!activeBusiness) return null;

  return (
    <div className="space-y-6">
       <BusinessSwitcher
          activeBusiness={activeBusiness}
          allBusinesses={appData.businesses}
          setActiveBusinessId={setActiveBusinessId}
          setCurrentView={setCurrentView}
       />

      <div className="grid grid-cols-2 gap-4">
        <StatCard title="Total Income" amount={totalIncome} currency={currency} className="text-light-income-fg dark:text-dark-income-fg" />
        <StatCard title="Total Expenses" amount={totalExpense} currency={currency} className="text-light-expense-fg dark:text-dark-expense-fg" />
      </div>
      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-4 rounded-2xl col-span-2">
        <h3 className="text-base font-medium text-light-fg-subtle dark:text-dark-fg-subtle">Net Profit</h3>
        <p className={`text-3xl font-bold ${netProfit >= 0 ? 'text-light-income-fg dark:text-dark-income-fg' : 'text-light-expense-fg dark:text-dark-expense-fg'}`}>
          {currency} {netProfit.toLocaleString()}
        </p>
      </div>
      
      {outstandingInvoices.length > 0 && (
        <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-4 rounded-2xl">
            <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default mb-2">Outstanding Invoices</h3>
            <ul className="divide-y divide-light-border-default dark:divide-dark-border-default">
                {outstandingInvoices.slice(0, 3).map(t => <OutstandingItem key={t.id} transaction={t} currency={currency} />)}
            </ul>
        </div>
      )}

      {billsToPay.length > 0 && (
        <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-4 rounded-2xl">
            <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default mb-2">Bills to Pay</h3>
            <ul className="divide-y divide-light-border-default dark:divide-dark-border-default">
                {billsToPay.slice(0, 3).map(t => <OutstandingItem key={t.id} transaction={t} currency={currency} />)}
            </ul>
        </div>
      )}


      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle p-4 rounded-2xl">
        <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default mb-4">Monthly Overview</h3>
        {chartData.length > 0 ? (
          <div style={{ width: '100%', height: 250 }}>
            <ResponsiveContainer>
              <BarChart data={chartData} margin={{ top: 5, right: 0, left: -25, bottom: 5 }}>
                <XAxis dataKey="name" stroke={isDark ? '#9CA3AF' : '#6B7280'} fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke={isDark ? '#9CA3AF' : '#6B7280'} fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${currency}${Number(value) / 1000}k`} />
                <Tooltip
                  cursor={{ fill: 'rgba(156, 163, 175, 0.1)' }}
                  contentStyle={{ 
                    backgroundColor: isDark ? '#1F2937' : '#FFFFFF',
                    border: '1px solid',
                    borderColor: isDark ? '#374151' : '#E5E7EB',
                    borderRadius: '0.75rem',
                  }}
                  labelStyle={{ color: isDark ? '#F9FAFB' : '#111827' }}
                />
                <Bar dataKey="income" name="Income" stackId="a" fill={incomeColor} radius={[8, 8, 0, 0]} />
                <Bar dataKey="expense" name="Expense" stackId="a" fill={expenseColor} radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <p className="text-light-fg-subtle dark:text-dark-fg-subtle text-center py-10">No transaction data for chart.</p>
        )}
      </div>
      
    </div>
  );
};

export default Dashboard;
