import React, { useState, useEffect } from 'react';
import { Vendor } from '../types';
import { CloseIcon } from './icons/CloseIcon';

interface AddVendorModalProps {
  onClose: () => void;
  onAddVendor?: (vendor: Omit<Vendor, 'id' | 'ownerId'>) => Promise<void> | void;
  onUpdateVendor?: (vendor: Vendor) => Promise<void> | void;
  vendorToEdit?: Vendor | null;
}

const AddVendorModal: React.FC<AddVendorModalProps> = ({ onClose, onAddVendor, onUpdateVendor, vendorToEdit }) => {
  const isEditMode = !!vendorToEdit;
  const [name, setName] = useState('');
  const [service, setService] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  useEffect(() => {
    if (isEditMode) {
        setName(vendorToEdit.name);
        setService(vendorToEdit.service || '');
        setEmail(vendorToEdit.email || '');
        setPhone(vendorToEdit.phone || '');
    }
  }, [vendorToEdit, isEditMode]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
        alert("Vendor name is required.");
        return;
    }
    if(isEditMode) {
        onUpdateVendor?.({ ...vendorToEdit, name, service, email, phone });
    } else {
        onAddVendor?.({ name, service, email, phone });
    }
    onClose();
  };
  
  const commonInputClasses = "w-full bg-light-bg-inset dark:bg-dark-bg-inset border-transparent focus:border-accent border-2 rounded-xl py-3 px-4 focus:outline-none focus:ring-0 text-light-fg-default dark:text-dark-fg-default placeholder:text-light-fg-subtle placeholder:dark:text-dark-fg-subtle transition-colors";
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in" onClick={onClose}>
      <div 
        className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl shadow-2xl w-full max-w-sm m-4 p-6 relative animate-slide-up border border-light-border-default/50 dark:border-dark-border-default"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-4 right-4 text-light-fg-subtle dark:text-dark-fg-subtle hover:text-light-fg-default dark:hover:text-dark-fg-default">
          <CloseIcon />
        </button>
        <h2 className="text-xl font-bold mb-6 text-light-fg-default dark:text-dark-fg-default">
            {isEditMode ? 'Edit Vendor' : 'Add New Vendor'}
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="text" placeholder="Vendor Name" value={name} onChange={e => setName(e.target.value)} className={commonInputClasses} required />
          <input type="text" placeholder="Service/Product (Optional)" value={service} onChange={e => setService(e.target.value)} className={commonInputClasses} />
          <input type="email" placeholder="Email (Optional)" value={email} onChange={e => setEmail(e.target.value)} className={commonInputClasses} />
          <input type="tel" placeholder="Phone (Optional)" value={phone} onChange={e => setPhone(e.target.value)} className={commonInputClasses} />
          
          <button type="submit" className="w-full bg-accent text-accent-fg font-bold py-3.5 px-4 rounded-xl hover:opacity-90 transition-opacity">
              {isEditMode ? 'Update Vendor' : 'Add Vendor'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddVendorModal;