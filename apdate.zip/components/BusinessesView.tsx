

import React, { useState } from 'react';
import { Business } from '../types';
import { BusinessIcon } from './icons/BusinessIcon';
import { EditIcon } from './icons/EditIcon';
import { PlusIcon } from './icons/PlusIcon';
import BusinessSettingsModal from './BusinessSettingsModal';
import { MicrophoneIcon } from './icons/MicrophoneIcon';
import BusinessVoiceInputModal from './BusinessVoiceInputModal';
import { useAppContext } from '../context/AppContext';

interface BusinessesViewProps {
}

type ModalState = 
    | { mode: 'addBusiness', initialData?: Partial<Business> }
    | { mode: 'editBusiness', business: Business }
    | null;


const BusinessesView: React.FC<BusinessesViewProps> = () => {
  const { appData, addBusiness, updateBusiness } = useAppContext();
  const { businesses } = appData;

  const [modalState, setModalState] = useState<ModalState>(null);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);

  const Section: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode, onManualAddClick?: () => void, onVoiceAddClick?: () => void}> = ({ title, icon, children, onManualAddClick, onVoiceAddClick }) => (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-3 text-sm font-semibold text-light-fg-subtle dark:text-dark-fg-subtle">
          {icon}
          <h3>{title.toUpperCase()}</h3>
        </div>
        <div className="flex items-center gap-2">
            {onVoiceAddClick && (
                 <button onClick={onVoiceAddClick} className="flex items-center gap-1.5 text-sm font-semibold text-accent hover:opacity-80 transition-opacity p-2 rounded-lg bg-light-bg-inset dark:bg-dark-bg-inset">
                    <MicrophoneIcon className="w-5 h-5" /> Voice
                </button>
            )}
            {onManualAddClick && (
                <button onClick={onManualAddClick} className="flex items-center gap-1 text-sm font-semibold text-accent hover:opacity-80 transition-opacity p-2 rounded-lg bg-light-bg-inset dark:bg-dark-bg-inset">
                    <PlusIcon className="w-5 h-5" /> Manual
                </button>
            )}
        </div>
      </div>
      <div className="bg-light-bg-subtle dark:bg-dark-bg-subtle rounded-2xl overflow-hidden border border-light-border-default dark:border-dark-border-default">
        {children}
      </div>
    </div>
  );
  
  const handleSaveBusiness = (businessData: Omit<Business, 'id' | 'ownerId'> & { id?: string }) => {
    if (businessData.id) {
        // This is an update
        if (modalState?.mode === 'editBusiness') {
            const fullBusinessData: Business = {
                ...modalState.business, // has original id and ownerId
                ...businessData, // has new data, and id
            };
            updateBusiness(fullBusinessData);
        }
    } else {
        // This is an add
        addBusiness(businessData);
    }
    setModalState(null);
  };
  
  const handleVoiceParseComplete = (data: Partial<Business>) => {
    setIsVoiceModalOpen(false);
    setModalState({ mode: 'addBusiness', initialData: data });
  };


  return (
    <>
      <div className="space-y-6">
        <Section 
            title="Businesses" 
            icon={<BusinessIcon />} 
            onManualAddClick={() => setModalState({ mode: 'addBusiness' })}
            onVoiceAddClick={() => setIsVoiceModalOpen(true)}
        >
          {businesses.map((business) => (
              <div 
                key={business.id} 
                className="flex items-center justify-between p-4 border-b border-light-border-default dark:border-dark-border-default last:border-b-0"
              >
                  <div className="flex-grow">
                    <span className="font-medium text-light-fg-default dark:text-dark-fg-default">{business.name}</span>
                  </div>
                   <div className="flex-shrink-0 ml-4 flex items-center gap-2">
                    <button onClick={() => setModalState({ mode: 'editBusiness', business })} className="p-2 rounded-md text-light-fg-subtle hover:text-accent hover:bg-light-bg-inset dark:hover:bg-dark-bg-inset transition-colors"><EditIcon /></button>
                  </div>
              </div>
          ))}
           {businesses.length === 0 && (
              <div className="text-center p-8 text-light-fg-subtle dark:text-dark-fg-subtle">
                  <h3 className="text-lg font-semibold text-light-fg-default dark:text-dark-fg-default">No businesses yet</h3>
                  <p className="mt-1">Add your first business to get started.</p>
              </div>
          )}
        </Section>
      </div>

      {(modalState?.mode === 'addBusiness' || modalState?.mode === 'editBusiness') && (
        <BusinessSettingsModal
            businessToEdit={modalState.mode === 'editBusiness' ? modalState.business : undefined}
            initialData={modalState.mode === 'addBusiness' ? modalState.initialData : undefined}
            onClose={() => setModalState(null)}
            onSave={handleSaveBusiness}
        />
      )}

      {isVoiceModalOpen && (
        <BusinessVoiceInputModal
          onClose={() => setIsVoiceModalOpen(false)}
          onParseComplete={handleVoiceParseComplete}
        />
      )}
    </>
  );
};

export default BusinessesView;